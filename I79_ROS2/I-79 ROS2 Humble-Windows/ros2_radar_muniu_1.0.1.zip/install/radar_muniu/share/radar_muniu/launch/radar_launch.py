# radar_muniu/launch/radar_launch.py
from launch import LaunchDescription
from launch_ros.actions import Node
from launch.substitutions import PathJoinSubstitution
from launch_ros.substitutions import FindPackageShare

def generate_launch_description():
    # 查找参数文件路径（推荐用这种方式，避免硬编码路径）
    params_path = PathJoinSubstitution([
        FindPackageShare("radar_muniu"),  # 包名
        "config",                         # 配置文件目录
        "radar_muniu_config.yaml"         # 参数文件名
    ])

    rviz_config_path = PathJoinSubstitution([
        FindPackageShare("radar_muniu"),  # 包名
        "rviz",                           # 配置文件目录（与你保存的目录一致）
        "radar_view.rviz"                 # 配置文件名（与你保存的一致）
    ])

    return LaunchDescription([
        # 启动雷达节点
        Node(
            package="radar_muniu",         # 包名
            executable="radar_muniu_node",       # 可执行文件名
            name="radar_muniu",             # 节点名称（可选，默认与可执行文件同名）
            output="screen",               # 日志输出到终端（默认输出到日志文件）
            #parameters=[params_path],      # 加载参数文件
        ),

        # 启动滤波节点（示例：假设另一个节点用于处理雷达数据）
        #Node(
        #    package="radar_filters",
        #    executable="filter_node",
        #    name="radar_filter",
        #    output="screen",
        #    parameters=[{"filter_type": "median"}],  # 直接设置参数（而非文件）
        #    remappings=[("/input", "/radar/objects"), ("/output", "/radar/filtered_objects")]
        #),

        # 启动RViz2（可视化）
        Node(
            package="rviz2",
            executable="rviz2",
            name="rviz2",
            arguments=["-d", PathJoinSubstitution([FindPackageShare("radar_muniu"), "rviz", "radar_view.rviz"])]
        )
    ])