#ifndef RADAR_MUNIU__COMM_INTERFACE_HPP_
#define RADAR_MUNIU__COMM_INTERFACE_HPP_

#include <vector>
#include <string>
#include <functional>

namespace radar_muniu
{
// 通信数据回调函数（接收二进制数据）
using DataCallback = std::function<void(const std::vector<uint8_t> & data)>;

// 通信接口抽象类
class CommInterface
{
public:
  virtual ~CommInterface() = default;

  // 初始化通信（如绑定端口、打开CAN设备）
  virtual bool init() = 0;

  // 启动接收（异步/线程接收，数据通过callback返回）
  virtual void start_receive(const DataCallback & callback) = 0;

  // 发送数据（可选，用于配置雷达）
  virtual bool send(const std::vector<uint8_t> & data) = 0;

  // 关闭通信
  virtual void close() = 0;
};

}  // namespace radar_muniu

#endif  // RADAR_MUNIU__COMM_INTERFACE_HPP_