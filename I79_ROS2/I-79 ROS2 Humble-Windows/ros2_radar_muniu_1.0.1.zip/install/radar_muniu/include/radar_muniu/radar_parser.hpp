// radar_parser.hpp
#include "rclcpp/rclcpp.hpp"
#include "radar_msgs/msg/detection_list.hpp"
#include "radar_msgs/msg/object_list.hpp"
#include "tf2_ros/transform_broadcaster.h"
#include "geometry_msgs/msg/transform_stamped.hpp"
#include "comm_interface.hpp"
#include <memory>
#include "udp_comm.hpp"   // 引入UDPConfig定义
#include "can_comm.hpp"   // 引入CANConfig定义
#include "tf2/LinearMath/Quaternion.h"
#include "tf2_ros/transform_broadcaster.h" 
#include "rclcpp/rclcpp.hpp"
#include "sensor_msgs/msg/laser_scan.hpp"
#include "tf2/LinearMath/Quaternion.h"
#include "tf2_ros/transform_broadcaster.h" 
#include "geometry_msgs/msg/transform_stamped.hpp" 
#include "sensor_msgs/msg/point_cloud2.hpp"
#include "std_msgs/msg/header.hpp"
#include "geometry_msgs/msg/transform_stamped.hpp"



namespace radar_muniu
{
	#define SERVICE_DETECT_ID  0x200C
	#define SERVICE_OBJECT_ID  0x300C
	#define SERVICE_VEHIVLE_ID 0x400C
	#define SERVICE_MONITOR_ID 0x500C
	#define SERVICE_RTK_ID     0x600C
	#define SERVICE_VERSION_ID 0x700C

	// 雷达配置结构体（整合通信+安装参数）
	struct RadarConfig
	{
		std::string radar_id;
		std::string frame_id;
		std::string parent_frame_id;
		std::string protocol;
		std::vector<std::string> service;
		UDPConfig udp_config;
		CANConfig can_config;
		// 安装位姿
		double x = 0, y = 0, z = 0;
		double roll = 0, pitch = 0, yaw = 0;
	};

	class RadarParser
	{
	public:
		RadarParser(rclcpp::Node* node, const RadarConfig& config);
		~RadarParser() = default;

		// 启动雷达（初始化通信+接收+TF发布）
		bool start();

		void stop();

	private:
		// 通信数据回调（解析入口）
		void on_data_received(const std::vector<uint8_t>& data);

		// 解析协议帧（区分DetectionList/ObjectList）
		void parse_protocol_frame(const std::vector<uint8_t>& data, uint16_t service_id, uint64_t frame_ts);

		// 解析DetectionList
		void parse_detection_list(const std::vector<uint8_t>& data, uint64_t frame_ts);

		// 解析ObjectList
		void parse_object_list(const std::vector<uint8_t>& data, uint64_t frame_ts);

		// 发布TF变换（雷达坐标系→父坐标系）
		void publish_tf();

		void on_connection_status_changed(bool connected);

		sensor_msgs::msg::PointCloud2 create_point_cloud(const std::string& frame_id, size_t point_count, const rclcpp::Time& timestamp);

		rclcpp::Node* node_;
		RadarConfig config_;
		std::unique_ptr<CommInterface> comm_;  // 通信实例
		// ROS 发布者
		rclcpp::Publisher<radar_msgs::msg::DetectionList>::SharedPtr det_list_pub_;
		rclcpp::Publisher<radar_msgs::msg::ObjectList>::SharedPtr obj_list_pub_;
		std::unique_ptr<tf2_ros::TransformBroadcaster> tf_broadcaster_;
		// TF 发布定时器（100ms周期）
		rclcpp::TimerBase::SharedPtr tf_timer_;

		rclcpp::Publisher<sensor_msgs::msg::PointCloud2>::SharedPtr pointcloud_pub_;
		rclcpp::Publisher<sensor_msgs::msg::PointCloud2>::SharedPtr pointtrack_pub_;

	private:
		uint32_t m_session_id = 0;
		std::vector<uint8_t> m_buffer;
	};

}  // namespace radar_muniu