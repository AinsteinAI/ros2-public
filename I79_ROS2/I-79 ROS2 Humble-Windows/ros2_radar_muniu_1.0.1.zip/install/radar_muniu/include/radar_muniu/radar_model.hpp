// radar_model.hpp
#pragma once
#include <vector>
#include <string>
#include <algorithm>

namespace radar_muniu
{

	class RadarModel
	{
	public:
		RadarModel();
		~RadarModel();

	public:
		std::vector<uint8_t> static getCmd(uint16_t service_id, std::string& local_ip, uint8_t op_type);

		static bool isLocalBigEndian()
		{
			int iData = 1;
			char* p = (char*)&iData;
			if (*p == 1)
			{
				return false;
			}
			else
			{
				return true;
			}
		}

		template <typename T>
		static unsigned char convert(T& val, unsigned char* src, bool isBigEndian = true)
		{
			unsigned char size = sizeof(T);
			unsigned char* dest = (unsigned char*)&val;
			if (isBigEndian == isLocalBigEndian())
			{
				std::copy(src, src + size, dest);
			}
			else
			{
				std::reverse_copy(src, src + size, dest);
			}
			return size;
		}

		template <typename ElemType, std::size_t N>
		static unsigned char convert(std::array<ElemType, N>& arr, unsigned char* src, bool isBigEndian = true)
		{
			unsigned char totalSize = 0;
			unsigned char elemSize = sizeof(ElemType);
			for (std::size_t i = 0; i < N; ++i)
			{
				// Ϊÿ��Ԫ�ص��û������͵�convert�������������ֽ���
				totalSize += convert(arr[i], src + totalSize, isBigEndian);
			}
			return totalSize;
		}

	};

}  // namespace radar_muniu