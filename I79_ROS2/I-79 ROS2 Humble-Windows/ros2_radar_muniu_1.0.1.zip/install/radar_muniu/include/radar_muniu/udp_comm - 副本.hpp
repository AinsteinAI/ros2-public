// udp_comm.hpp
#pragma once
#include "comm_interface.hpp"
#include "rclcpp/rclcpp.hpp"
#include "asio.hpp"
#include <thread>
#include <atomic>

namespace radar_muniu
{
struct UDPConfig
{
  std::string local_ip;
  uint16_t local_port;
  std::string remote_ip;
  uint16_t remote_port;
};

class UDPComm : public CommInterface
{
public:
  UDPComm(rclcpp::Node * node, const UDPConfig & config);
  ~UDPComm() override;

  bool init() override;
  void start_receive(const DataCallback & callback) override;
  bool send(const std::vector<uint8_t> & data) override;
  void close() override;

private:
  // 异步接收处理
  void do_receive();

  rclcpp::Node * node_;
  UDPConfig config_;
  asio::io_context io_ctx_;
  asio::ip::udp::socket socket_;
  asio::ip::udp::endpoint remote_ep_;
  std::thread io_thread_;
  std::atomic<bool> is_running_;
  DataCallback data_callback_;
  std::array<uint8_t, 4096*10> recv_buf_;  // 接收缓冲区
};

}  // namespace radar_muniu