// can_comm.hpp
#pragma once
#include "comm_interface.hpp"
#include "rclcpp/rclcpp.hpp"
//#include <linux/can.h>
#include <thread>
#include <atomic>

namespace radar_muniu
{
	struct CANConfig
	{
		std::string device;  // 设备名（如can0）
		uint32_t bitrate;    // 波特率
		uint32_t rx_id;       // 接收ID
		uint32_t tx_id;       // 发送ID
	};

	class CANComm : public CommInterface
	{
	public:
		CANComm(rclcpp::Node* node, const CANConfig& config);
		~CANComm() override;

		bool init() override;
		void start_receive(const DataCallback& callback) override;
		bool send(const std::vector<uint8_t>& data) override;
		void close() override;

	private:
		// 接收线程函数
		void receive_thread();

		rclcpp::Node* node_;
		CANConfig config_;
		int can_fd_;  // CAN 设备文件描述符
		std::thread recv_thread_;
		std::atomic<bool> is_running_;
		DataCallback data_callback_;
	};

}  // namespace radar_muniu