# generated from rosidl_cmake/cmake/rosidl_cmake-extras.cmake.in

set(radar_msgs_IDL_FILES "msg/Detection.idl;msg/DetectionList.idl;msg/Object.idl;msg/ObjectList.idl")
set(radar_msgs_INTERFACE_FILES "msg/Detection.msg;msg/DetectionList.msg;msg/Object.msg;msg/ObjectList.msg")
