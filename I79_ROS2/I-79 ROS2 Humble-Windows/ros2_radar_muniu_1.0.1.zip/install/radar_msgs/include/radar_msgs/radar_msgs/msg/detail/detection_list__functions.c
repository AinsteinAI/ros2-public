// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from radar_msgs:msg\DetectionList.idl
// generated code does not contain a copyright notice
#include "radar_msgs/msg/detail/detection_list__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"
// Member `list_detections`
#include "radar_msgs/msg/detail/detection__functions.h"

bool
radar_msgs__msg__DetectionList__init(radar_msgs__msg__DetectionList * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    radar_msgs__msg__DetectionList__fini(msg);
    return false;
  }
  // crc
  // length
  // sqc
  // data_id
  // version_code
  // frame_count
  // frame_period_time
  // timestamp_nanoseconds
  // timestamp_seconds
  // timestamp_sync_status
  // rsv1
  // rsv2
  // coordinate_system
  // measurement_latency
  // origin_invalid_flags
  // origin_xpos
  // origin_xstd
  // origin_ypos
  // origin_ystd
  // origin_zpos
  // origin_zstd
  // origin_roll
  // origin_rollstd
  // origin_pitch
  // origin_pitchstd
  // origin_yaw
  // origin_yawstd
  // list_invalid_flags
  // aln_azimuth_correction
  // aln_elevation_correction
  // rsv_weather
  // rsv_road_status
  // rsv_aucc_frame_count
  // rsv_profile_id
  // rsv_adc_anti_num
  // rsv_adc_real_higer_thod_cnt
  // rsv_adc_imag_higer_thod_cnt
  // u_rsv_bfm_coeff_error_flag
  // rsv_ci_noise_median
  // rsv_nci_noise_median
  // rsv3
  // list_len_of_detections
  // list_num_of_detections
  // list_detections
  if (!radar_msgs__msg__Detection__Sequence__init(&msg->list_detections, 0)) {
    radar_msgs__msg__DetectionList__fini(msg);
    return false;
  }
  return true;
}

void
radar_msgs__msg__DetectionList__fini(radar_msgs__msg__DetectionList * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // crc
  // length
  // sqc
  // data_id
  // version_code
  // frame_count
  // frame_period_time
  // timestamp_nanoseconds
  // timestamp_seconds
  // timestamp_sync_status
  // rsv1
  // rsv2
  // coordinate_system
  // measurement_latency
  // origin_invalid_flags
  // origin_xpos
  // origin_xstd
  // origin_ypos
  // origin_ystd
  // origin_zpos
  // origin_zstd
  // origin_roll
  // origin_rollstd
  // origin_pitch
  // origin_pitchstd
  // origin_yaw
  // origin_yawstd
  // list_invalid_flags
  // aln_azimuth_correction
  // aln_elevation_correction
  // rsv_weather
  // rsv_road_status
  // rsv_aucc_frame_count
  // rsv_profile_id
  // rsv_adc_anti_num
  // rsv_adc_real_higer_thod_cnt
  // rsv_adc_imag_higer_thod_cnt
  // u_rsv_bfm_coeff_error_flag
  // rsv_ci_noise_median
  // rsv_nci_noise_median
  // rsv3
  // list_len_of_detections
  // list_num_of_detections
  // list_detections
  radar_msgs__msg__Detection__Sequence__fini(&msg->list_detections);
}

bool
radar_msgs__msg__DetectionList__are_equal(const radar_msgs__msg__DetectionList * lhs, const radar_msgs__msg__DetectionList * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // crc
  if (lhs->crc != rhs->crc) {
    return false;
  }
  // length
  if (lhs->length != rhs->length) {
    return false;
  }
  // sqc
  if (lhs->sqc != rhs->sqc) {
    return false;
  }
  // data_id
  if (lhs->data_id != rhs->data_id) {
    return false;
  }
  // version_code
  if (lhs->version_code != rhs->version_code) {
    return false;
  }
  // frame_count
  if (lhs->frame_count != rhs->frame_count) {
    return false;
  }
  // frame_period_time
  if (lhs->frame_period_time != rhs->frame_period_time) {
    return false;
  }
  // timestamp_nanoseconds
  if (lhs->timestamp_nanoseconds != rhs->timestamp_nanoseconds) {
    return false;
  }
  // timestamp_seconds
  if (lhs->timestamp_seconds != rhs->timestamp_seconds) {
    return false;
  }
  // timestamp_sync_status
  if (lhs->timestamp_sync_status != rhs->timestamp_sync_status) {
    return false;
  }
  // rsv1
  if (lhs->rsv1 != rhs->rsv1) {
    return false;
  }
  // rsv2
  if (lhs->rsv2 != rhs->rsv2) {
    return false;
  }
  // coordinate_system
  if (lhs->coordinate_system != rhs->coordinate_system) {
    return false;
  }
  // measurement_latency
  if (lhs->measurement_latency != rhs->measurement_latency) {
    return false;
  }
  // origin_invalid_flags
  if (lhs->origin_invalid_flags != rhs->origin_invalid_flags) {
    return false;
  }
  // origin_xpos
  if (lhs->origin_xpos != rhs->origin_xpos) {
    return false;
  }
  // origin_xstd
  if (lhs->origin_xstd != rhs->origin_xstd) {
    return false;
  }
  // origin_ypos
  if (lhs->origin_ypos != rhs->origin_ypos) {
    return false;
  }
  // origin_ystd
  if (lhs->origin_ystd != rhs->origin_ystd) {
    return false;
  }
  // origin_zpos
  if (lhs->origin_zpos != rhs->origin_zpos) {
    return false;
  }
  // origin_zstd
  if (lhs->origin_zstd != rhs->origin_zstd) {
    return false;
  }
  // origin_roll
  if (lhs->origin_roll != rhs->origin_roll) {
    return false;
  }
  // origin_rollstd
  if (lhs->origin_rollstd != rhs->origin_rollstd) {
    return false;
  }
  // origin_pitch
  if (lhs->origin_pitch != rhs->origin_pitch) {
    return false;
  }
  // origin_pitchstd
  if (lhs->origin_pitchstd != rhs->origin_pitchstd) {
    return false;
  }
  // origin_yaw
  if (lhs->origin_yaw != rhs->origin_yaw) {
    return false;
  }
  // origin_yawstd
  if (lhs->origin_yawstd != rhs->origin_yawstd) {
    return false;
  }
  // list_invalid_flags
  if (lhs->list_invalid_flags != rhs->list_invalid_flags) {
    return false;
  }
  // aln_azimuth_correction
  if (lhs->aln_azimuth_correction != rhs->aln_azimuth_correction) {
    return false;
  }
  // aln_elevation_correction
  if (lhs->aln_elevation_correction != rhs->aln_elevation_correction) {
    return false;
  }
  // rsv_weather
  if (lhs->rsv_weather != rhs->rsv_weather) {
    return false;
  }
  // rsv_road_status
  if (lhs->rsv_road_status != rhs->rsv_road_status) {
    return false;
  }
  // rsv_aucc_frame_count
  if (lhs->rsv_aucc_frame_count != rhs->rsv_aucc_frame_count) {
    return false;
  }
  // rsv_profile_id
  if (lhs->rsv_profile_id != rhs->rsv_profile_id) {
    return false;
  }
  // rsv_adc_anti_num
  if (lhs->rsv_adc_anti_num != rhs->rsv_adc_anti_num) {
    return false;
  }
  // rsv_adc_real_higer_thod_cnt
  if (lhs->rsv_adc_real_higer_thod_cnt != rhs->rsv_adc_real_higer_thod_cnt) {
    return false;
  }
  // rsv_adc_imag_higer_thod_cnt
  if (lhs->rsv_adc_imag_higer_thod_cnt != rhs->rsv_adc_imag_higer_thod_cnt) {
    return false;
  }
  // u_rsv_bfm_coeff_error_flag
  if (lhs->u_rsv_bfm_coeff_error_flag != rhs->u_rsv_bfm_coeff_error_flag) {
    return false;
  }
  // rsv_ci_noise_median
  if (lhs->rsv_ci_noise_median != rhs->rsv_ci_noise_median) {
    return false;
  }
  // rsv_nci_noise_median
  if (lhs->rsv_nci_noise_median != rhs->rsv_nci_noise_median) {
    return false;
  }
  // rsv3
  for (size_t i = 0; i < 16; ++i) {
    if (lhs->rsv3[i] != rhs->rsv3[i]) {
      return false;
    }
  }
  // list_len_of_detections
  if (lhs->list_len_of_detections != rhs->list_len_of_detections) {
    return false;
  }
  // list_num_of_detections
  if (lhs->list_num_of_detections != rhs->list_num_of_detections) {
    return false;
  }
  // list_detections
  if (!radar_msgs__msg__Detection__Sequence__are_equal(
      &(lhs->list_detections), &(rhs->list_detections)))
  {
    return false;
  }
  return true;
}

bool
radar_msgs__msg__DetectionList__copy(
  const radar_msgs__msg__DetectionList * input,
  radar_msgs__msg__DetectionList * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // crc
  output->crc = input->crc;
  // length
  output->length = input->length;
  // sqc
  output->sqc = input->sqc;
  // data_id
  output->data_id = input->data_id;
  // version_code
  output->version_code = input->version_code;
  // frame_count
  output->frame_count = input->frame_count;
  // frame_period_time
  output->frame_period_time = input->frame_period_time;
  // timestamp_nanoseconds
  output->timestamp_nanoseconds = input->timestamp_nanoseconds;
  // timestamp_seconds
  output->timestamp_seconds = input->timestamp_seconds;
  // timestamp_sync_status
  output->timestamp_sync_status = input->timestamp_sync_status;
  // rsv1
  output->rsv1 = input->rsv1;
  // rsv2
  output->rsv2 = input->rsv2;
  // coordinate_system
  output->coordinate_system = input->coordinate_system;
  // measurement_latency
  output->measurement_latency = input->measurement_latency;
  // origin_invalid_flags
  output->origin_invalid_flags = input->origin_invalid_flags;
  // origin_xpos
  output->origin_xpos = input->origin_xpos;
  // origin_xstd
  output->origin_xstd = input->origin_xstd;
  // origin_ypos
  output->origin_ypos = input->origin_ypos;
  // origin_ystd
  output->origin_ystd = input->origin_ystd;
  // origin_zpos
  output->origin_zpos = input->origin_zpos;
  // origin_zstd
  output->origin_zstd = input->origin_zstd;
  // origin_roll
  output->origin_roll = input->origin_roll;
  // origin_rollstd
  output->origin_rollstd = input->origin_rollstd;
  // origin_pitch
  output->origin_pitch = input->origin_pitch;
  // origin_pitchstd
  output->origin_pitchstd = input->origin_pitchstd;
  // origin_yaw
  output->origin_yaw = input->origin_yaw;
  // origin_yawstd
  output->origin_yawstd = input->origin_yawstd;
  // list_invalid_flags
  output->list_invalid_flags = input->list_invalid_flags;
  // aln_azimuth_correction
  output->aln_azimuth_correction = input->aln_azimuth_correction;
  // aln_elevation_correction
  output->aln_elevation_correction = input->aln_elevation_correction;
  // rsv_weather
  output->rsv_weather = input->rsv_weather;
  // rsv_road_status
  output->rsv_road_status = input->rsv_road_status;
  // rsv_aucc_frame_count
  output->rsv_aucc_frame_count = input->rsv_aucc_frame_count;
  // rsv_profile_id
  output->rsv_profile_id = input->rsv_profile_id;
  // rsv_adc_anti_num
  output->rsv_adc_anti_num = input->rsv_adc_anti_num;
  // rsv_adc_real_higer_thod_cnt
  output->rsv_adc_real_higer_thod_cnt = input->rsv_adc_real_higer_thod_cnt;
  // rsv_adc_imag_higer_thod_cnt
  output->rsv_adc_imag_higer_thod_cnt = input->rsv_adc_imag_higer_thod_cnt;
  // u_rsv_bfm_coeff_error_flag
  output->u_rsv_bfm_coeff_error_flag = input->u_rsv_bfm_coeff_error_flag;
  // rsv_ci_noise_median
  output->rsv_ci_noise_median = input->rsv_ci_noise_median;
  // rsv_nci_noise_median
  output->rsv_nci_noise_median = input->rsv_nci_noise_median;
  // rsv3
  for (size_t i = 0; i < 16; ++i) {
    output->rsv3[i] = input->rsv3[i];
  }
  // list_len_of_detections
  output->list_len_of_detections = input->list_len_of_detections;
  // list_num_of_detections
  output->list_num_of_detections = input->list_num_of_detections;
  // list_detections
  if (!radar_msgs__msg__Detection__Sequence__copy(
      &(input->list_detections), &(output->list_detections)))
  {
    return false;
  }
  return true;
}

radar_msgs__msg__DetectionList *
radar_msgs__msg__DetectionList__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__DetectionList * msg = (radar_msgs__msg__DetectionList *)allocator.allocate(sizeof(radar_msgs__msg__DetectionList), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(radar_msgs__msg__DetectionList));
  bool success = radar_msgs__msg__DetectionList__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
radar_msgs__msg__DetectionList__destroy(radar_msgs__msg__DetectionList * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    radar_msgs__msg__DetectionList__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
radar_msgs__msg__DetectionList__Sequence__init(radar_msgs__msg__DetectionList__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__DetectionList * data = NULL;

  if (size) {
    data = (radar_msgs__msg__DetectionList *)allocator.zero_allocate(size, sizeof(radar_msgs__msg__DetectionList), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = radar_msgs__msg__DetectionList__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        radar_msgs__msg__DetectionList__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
radar_msgs__msg__DetectionList__Sequence__fini(radar_msgs__msg__DetectionList__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      radar_msgs__msg__DetectionList__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

radar_msgs__msg__DetectionList__Sequence *
radar_msgs__msg__DetectionList__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__DetectionList__Sequence * array = (radar_msgs__msg__DetectionList__Sequence *)allocator.allocate(sizeof(radar_msgs__msg__DetectionList__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = radar_msgs__msg__DetectionList__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
radar_msgs__msg__DetectionList__Sequence__destroy(radar_msgs__msg__DetectionList__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    radar_msgs__msg__DetectionList__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
radar_msgs__msg__DetectionList__Sequence__are_equal(const radar_msgs__msg__DetectionList__Sequence * lhs, const radar_msgs__msg__DetectionList__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!radar_msgs__msg__DetectionList__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
radar_msgs__msg__DetectionList__Sequence__copy(
  const radar_msgs__msg__DetectionList__Sequence * input,
  radar_msgs__msg__DetectionList__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(radar_msgs__msg__DetectionList);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    radar_msgs__msg__DetectionList * data =
      (radar_msgs__msg__DetectionList *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!radar_msgs__msg__DetectionList__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          radar_msgs__msg__DetectionList__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!radar_msgs__msg__DetectionList__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
