// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from radar_msgs:msg\DetectionList.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__DETECTION_LIST__STRUCT_HPP_
#define RADAR_MSGS__MSG__DETAIL__DETECTION_LIST__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"
// Member 'list_detections'
#include "radar_msgs/msg/detail/detection__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__radar_msgs__msg__DetectionList __attribute__((deprecated))
#else
# define DEPRECATED__radar_msgs__msg__DetectionList __declspec(deprecated)
#endif

namespace radar_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct DetectionList_
{
  using Type = DetectionList_<ContainerAllocator>;

  explicit DetectionList_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->crc = 0ull;
      this->length = 0ul;
      this->sqc = 0ul;
      this->data_id = 0ul;
      this->version_code = 0;
      this->frame_count = 0ul;
      this->frame_period_time = 0;
      this->timestamp_nanoseconds = 0ul;
      this->timestamp_seconds = 0ul;
      this->timestamp_sync_status = 0;
      this->rsv1 = 0ul;
      this->rsv2 = 0;
      this->coordinate_system = 0;
      this->measurement_latency = 0.0f;
      this->origin_invalid_flags = 0;
      this->origin_xpos = 0.0f;
      this->origin_xstd = 0.0f;
      this->origin_ypos = 0.0f;
      this->origin_ystd = 0.0f;
      this->origin_zpos = 0.0f;
      this->origin_zstd = 0.0f;
      this->origin_roll = 0.0f;
      this->origin_rollstd = 0.0f;
      this->origin_pitch = 0.0f;
      this->origin_pitchstd = 0.0f;
      this->origin_yaw = 0.0f;
      this->origin_yawstd = 0.0f;
      this->list_invalid_flags = 0;
      this->aln_azimuth_correction = 0.0f;
      this->aln_elevation_correction = 0.0f;
      this->rsv_weather = 0;
      this->rsv_road_status = 0;
      this->rsv_aucc_frame_count = 0;
      this->rsv_profile_id = 0;
      this->rsv_adc_anti_num = 0ul;
      this->rsv_adc_real_higer_thod_cnt = 0ul;
      this->rsv_adc_imag_higer_thod_cnt = 0ul;
      this->u_rsv_bfm_coeff_error_flag = 0;
      this->rsv_ci_noise_median = 0ul;
      this->rsv_nci_noise_median = 0ul;
      std::fill<typename std::array<uint8_t, 16>::iterator, uint8_t>(this->rsv3.begin(), this->rsv3.end(), 0);
      this->list_len_of_detections = 0;
      this->list_num_of_detections = 0ul;
    }
  }

  explicit DetectionList_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init),
    rsv3(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->crc = 0ull;
      this->length = 0ul;
      this->sqc = 0ul;
      this->data_id = 0ul;
      this->version_code = 0;
      this->frame_count = 0ul;
      this->frame_period_time = 0;
      this->timestamp_nanoseconds = 0ul;
      this->timestamp_seconds = 0ul;
      this->timestamp_sync_status = 0;
      this->rsv1 = 0ul;
      this->rsv2 = 0;
      this->coordinate_system = 0;
      this->measurement_latency = 0.0f;
      this->origin_invalid_flags = 0;
      this->origin_xpos = 0.0f;
      this->origin_xstd = 0.0f;
      this->origin_ypos = 0.0f;
      this->origin_ystd = 0.0f;
      this->origin_zpos = 0.0f;
      this->origin_zstd = 0.0f;
      this->origin_roll = 0.0f;
      this->origin_rollstd = 0.0f;
      this->origin_pitch = 0.0f;
      this->origin_pitchstd = 0.0f;
      this->origin_yaw = 0.0f;
      this->origin_yawstd = 0.0f;
      this->list_invalid_flags = 0;
      this->aln_azimuth_correction = 0.0f;
      this->aln_elevation_correction = 0.0f;
      this->rsv_weather = 0;
      this->rsv_road_status = 0;
      this->rsv_aucc_frame_count = 0;
      this->rsv_profile_id = 0;
      this->rsv_adc_anti_num = 0ul;
      this->rsv_adc_real_higer_thod_cnt = 0ul;
      this->rsv_adc_imag_higer_thod_cnt = 0ul;
      this->u_rsv_bfm_coeff_error_flag = 0;
      this->rsv_ci_noise_median = 0ul;
      this->rsv_nci_noise_median = 0ul;
      std::fill<typename std::array<uint8_t, 16>::iterator, uint8_t>(this->rsv3.begin(), this->rsv3.end(), 0);
      this->list_len_of_detections = 0;
      this->list_num_of_detections = 0ul;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _crc_type =
    uint64_t;
  _crc_type crc;
  using _length_type =
    uint32_t;
  _length_type length;
  using _sqc_type =
    uint32_t;
  _sqc_type sqc;
  using _data_id_type =
    uint32_t;
  _data_id_type data_id;
  using _version_code_type =
    uint16_t;
  _version_code_type version_code;
  using _frame_count_type =
    uint32_t;
  _frame_count_type frame_count;
  using _frame_period_time_type =
    uint8_t;
  _frame_period_time_type frame_period_time;
  using _timestamp_nanoseconds_type =
    uint32_t;
  _timestamp_nanoseconds_type timestamp_nanoseconds;
  using _timestamp_seconds_type =
    uint32_t;
  _timestamp_seconds_type timestamp_seconds;
  using _timestamp_sync_status_type =
    uint8_t;
  _timestamp_sync_status_type timestamp_sync_status;
  using _rsv1_type =
    uint32_t;
  _rsv1_type rsv1;
  using _rsv2_type =
    uint8_t;
  _rsv2_type rsv2;
  using _coordinate_system_type =
    uint8_t;
  _coordinate_system_type coordinate_system;
  using _measurement_latency_type =
    float;
  _measurement_latency_type measurement_latency;
  using _origin_invalid_flags_type =
    uint16_t;
  _origin_invalid_flags_type origin_invalid_flags;
  using _origin_xpos_type =
    float;
  _origin_xpos_type origin_xpos;
  using _origin_xstd_type =
    float;
  _origin_xstd_type origin_xstd;
  using _origin_ypos_type =
    float;
  _origin_ypos_type origin_ypos;
  using _origin_ystd_type =
    float;
  _origin_ystd_type origin_ystd;
  using _origin_zpos_type =
    float;
  _origin_zpos_type origin_zpos;
  using _origin_zstd_type =
    float;
  _origin_zstd_type origin_zstd;
  using _origin_roll_type =
    float;
  _origin_roll_type origin_roll;
  using _origin_rollstd_type =
    float;
  _origin_rollstd_type origin_rollstd;
  using _origin_pitch_type =
    float;
  _origin_pitch_type origin_pitch;
  using _origin_pitchstd_type =
    float;
  _origin_pitchstd_type origin_pitchstd;
  using _origin_yaw_type =
    float;
  _origin_yaw_type origin_yaw;
  using _origin_yawstd_type =
    float;
  _origin_yawstd_type origin_yawstd;
  using _list_invalid_flags_type =
    uint8_t;
  _list_invalid_flags_type list_invalid_flags;
  using _aln_azimuth_correction_type =
    float;
  _aln_azimuth_correction_type aln_azimuth_correction;
  using _aln_elevation_correction_type =
    float;
  _aln_elevation_correction_type aln_elevation_correction;
  using _rsv_weather_type =
    uint8_t;
  _rsv_weather_type rsv_weather;
  using _rsv_road_status_type =
    uint8_t;
  _rsv_road_status_type rsv_road_status;
  using _rsv_aucc_frame_count_type =
    uint8_t;
  _rsv_aucc_frame_count_type rsv_aucc_frame_count;
  using _rsv_profile_id_type =
    uint8_t;
  _rsv_profile_id_type rsv_profile_id;
  using _rsv_adc_anti_num_type =
    uint32_t;
  _rsv_adc_anti_num_type rsv_adc_anti_num;
  using _rsv_adc_real_higer_thod_cnt_type =
    uint32_t;
  _rsv_adc_real_higer_thod_cnt_type rsv_adc_real_higer_thod_cnt;
  using _rsv_adc_imag_higer_thod_cnt_type =
    uint32_t;
  _rsv_adc_imag_higer_thod_cnt_type rsv_adc_imag_higer_thod_cnt;
  using _u_rsv_bfm_coeff_error_flag_type =
    uint8_t;
  _u_rsv_bfm_coeff_error_flag_type u_rsv_bfm_coeff_error_flag;
  using _rsv_ci_noise_median_type =
    uint32_t;
  _rsv_ci_noise_median_type rsv_ci_noise_median;
  using _rsv_nci_noise_median_type =
    uint32_t;
  _rsv_nci_noise_median_type rsv_nci_noise_median;
  using _rsv3_type =
    std::array<uint8_t, 16>;
  _rsv3_type rsv3;
  using _list_len_of_detections_type =
    uint8_t;
  _list_len_of_detections_type list_len_of_detections;
  using _list_num_of_detections_type =
    uint32_t;
  _list_num_of_detections_type list_num_of_detections;
  using _list_detections_type =
    std::vector<radar_msgs::msg::Detection_<ContainerAllocator>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<radar_msgs::msg::Detection_<ContainerAllocator>>>;
  _list_detections_type list_detections;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__crc(
    const uint64_t & _arg)
  {
    this->crc = _arg;
    return *this;
  }
  Type & set__length(
    const uint32_t & _arg)
  {
    this->length = _arg;
    return *this;
  }
  Type & set__sqc(
    const uint32_t & _arg)
  {
    this->sqc = _arg;
    return *this;
  }
  Type & set__data_id(
    const uint32_t & _arg)
  {
    this->data_id = _arg;
    return *this;
  }
  Type & set__version_code(
    const uint16_t & _arg)
  {
    this->version_code = _arg;
    return *this;
  }
  Type & set__frame_count(
    const uint32_t & _arg)
  {
    this->frame_count = _arg;
    return *this;
  }
  Type & set__frame_period_time(
    const uint8_t & _arg)
  {
    this->frame_period_time = _arg;
    return *this;
  }
  Type & set__timestamp_nanoseconds(
    const uint32_t & _arg)
  {
    this->timestamp_nanoseconds = _arg;
    return *this;
  }
  Type & set__timestamp_seconds(
    const uint32_t & _arg)
  {
    this->timestamp_seconds = _arg;
    return *this;
  }
  Type & set__timestamp_sync_status(
    const uint8_t & _arg)
  {
    this->timestamp_sync_status = _arg;
    return *this;
  }
  Type & set__rsv1(
    const uint32_t & _arg)
  {
    this->rsv1 = _arg;
    return *this;
  }
  Type & set__rsv2(
    const uint8_t & _arg)
  {
    this->rsv2 = _arg;
    return *this;
  }
  Type & set__coordinate_system(
    const uint8_t & _arg)
  {
    this->coordinate_system = _arg;
    return *this;
  }
  Type & set__measurement_latency(
    const float & _arg)
  {
    this->measurement_latency = _arg;
    return *this;
  }
  Type & set__origin_invalid_flags(
    const uint16_t & _arg)
  {
    this->origin_invalid_flags = _arg;
    return *this;
  }
  Type & set__origin_xpos(
    const float & _arg)
  {
    this->origin_xpos = _arg;
    return *this;
  }
  Type & set__origin_xstd(
    const float & _arg)
  {
    this->origin_xstd = _arg;
    return *this;
  }
  Type & set__origin_ypos(
    const float & _arg)
  {
    this->origin_ypos = _arg;
    return *this;
  }
  Type & set__origin_ystd(
    const float & _arg)
  {
    this->origin_ystd = _arg;
    return *this;
  }
  Type & set__origin_zpos(
    const float & _arg)
  {
    this->origin_zpos = _arg;
    return *this;
  }
  Type & set__origin_zstd(
    const float & _arg)
  {
    this->origin_zstd = _arg;
    return *this;
  }
  Type & set__origin_roll(
    const float & _arg)
  {
    this->origin_roll = _arg;
    return *this;
  }
  Type & set__origin_rollstd(
    const float & _arg)
  {
    this->origin_rollstd = _arg;
    return *this;
  }
  Type & set__origin_pitch(
    const float & _arg)
  {
    this->origin_pitch = _arg;
    return *this;
  }
  Type & set__origin_pitchstd(
    const float & _arg)
  {
    this->origin_pitchstd = _arg;
    return *this;
  }
  Type & set__origin_yaw(
    const float & _arg)
  {
    this->origin_yaw = _arg;
    return *this;
  }
  Type & set__origin_yawstd(
    const float & _arg)
  {
    this->origin_yawstd = _arg;
    return *this;
  }
  Type & set__list_invalid_flags(
    const uint8_t & _arg)
  {
    this->list_invalid_flags = _arg;
    return *this;
  }
  Type & set__aln_azimuth_correction(
    const float & _arg)
  {
    this->aln_azimuth_correction = _arg;
    return *this;
  }
  Type & set__aln_elevation_correction(
    const float & _arg)
  {
    this->aln_elevation_correction = _arg;
    return *this;
  }
  Type & set__rsv_weather(
    const uint8_t & _arg)
  {
    this->rsv_weather = _arg;
    return *this;
  }
  Type & set__rsv_road_status(
    const uint8_t & _arg)
  {
    this->rsv_road_status = _arg;
    return *this;
  }
  Type & set__rsv_aucc_frame_count(
    const uint8_t & _arg)
  {
    this->rsv_aucc_frame_count = _arg;
    return *this;
  }
  Type & set__rsv_profile_id(
    const uint8_t & _arg)
  {
    this->rsv_profile_id = _arg;
    return *this;
  }
  Type & set__rsv_adc_anti_num(
    const uint32_t & _arg)
  {
    this->rsv_adc_anti_num = _arg;
    return *this;
  }
  Type & set__rsv_adc_real_higer_thod_cnt(
    const uint32_t & _arg)
  {
    this->rsv_adc_real_higer_thod_cnt = _arg;
    return *this;
  }
  Type & set__rsv_adc_imag_higer_thod_cnt(
    const uint32_t & _arg)
  {
    this->rsv_adc_imag_higer_thod_cnt = _arg;
    return *this;
  }
  Type & set__u_rsv_bfm_coeff_error_flag(
    const uint8_t & _arg)
  {
    this->u_rsv_bfm_coeff_error_flag = _arg;
    return *this;
  }
  Type & set__rsv_ci_noise_median(
    const uint32_t & _arg)
  {
    this->rsv_ci_noise_median = _arg;
    return *this;
  }
  Type & set__rsv_nci_noise_median(
    const uint32_t & _arg)
  {
    this->rsv_nci_noise_median = _arg;
    return *this;
  }
  Type & set__rsv3(
    const std::array<uint8_t, 16> & _arg)
  {
    this->rsv3 = _arg;
    return *this;
  }
  Type & set__list_len_of_detections(
    const uint8_t & _arg)
  {
    this->list_len_of_detections = _arg;
    return *this;
  }
  Type & set__list_num_of_detections(
    const uint32_t & _arg)
  {
    this->list_num_of_detections = _arg;
    return *this;
  }
  Type & set__list_detections(
    const std::vector<radar_msgs::msg::Detection_<ContainerAllocator>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<radar_msgs::msg::Detection_<ContainerAllocator>>> & _arg)
  {
    this->list_detections = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    radar_msgs::msg::DetectionList_<ContainerAllocator> *;
  using ConstRawPtr =
    const radar_msgs::msg::DetectionList_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<radar_msgs::msg::DetectionList_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<radar_msgs::msg::DetectionList_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      radar_msgs::msg::DetectionList_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<radar_msgs::msg::DetectionList_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      radar_msgs::msg::DetectionList_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<radar_msgs::msg::DetectionList_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<radar_msgs::msg::DetectionList_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<radar_msgs::msg::DetectionList_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__radar_msgs__msg__DetectionList
    std::shared_ptr<radar_msgs::msg::DetectionList_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__radar_msgs__msg__DetectionList
    std::shared_ptr<radar_msgs::msg::DetectionList_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const DetectionList_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->crc != other.crc) {
      return false;
    }
    if (this->length != other.length) {
      return false;
    }
    if (this->sqc != other.sqc) {
      return false;
    }
    if (this->data_id != other.data_id) {
      return false;
    }
    if (this->version_code != other.version_code) {
      return false;
    }
    if (this->frame_count != other.frame_count) {
      return false;
    }
    if (this->frame_period_time != other.frame_period_time) {
      return false;
    }
    if (this->timestamp_nanoseconds != other.timestamp_nanoseconds) {
      return false;
    }
    if (this->timestamp_seconds != other.timestamp_seconds) {
      return false;
    }
    if (this->timestamp_sync_status != other.timestamp_sync_status) {
      return false;
    }
    if (this->rsv1 != other.rsv1) {
      return false;
    }
    if (this->rsv2 != other.rsv2) {
      return false;
    }
    if (this->coordinate_system != other.coordinate_system) {
      return false;
    }
    if (this->measurement_latency != other.measurement_latency) {
      return false;
    }
    if (this->origin_invalid_flags != other.origin_invalid_flags) {
      return false;
    }
    if (this->origin_xpos != other.origin_xpos) {
      return false;
    }
    if (this->origin_xstd != other.origin_xstd) {
      return false;
    }
    if (this->origin_ypos != other.origin_ypos) {
      return false;
    }
    if (this->origin_ystd != other.origin_ystd) {
      return false;
    }
    if (this->origin_zpos != other.origin_zpos) {
      return false;
    }
    if (this->origin_zstd != other.origin_zstd) {
      return false;
    }
    if (this->origin_roll != other.origin_roll) {
      return false;
    }
    if (this->origin_rollstd != other.origin_rollstd) {
      return false;
    }
    if (this->origin_pitch != other.origin_pitch) {
      return false;
    }
    if (this->origin_pitchstd != other.origin_pitchstd) {
      return false;
    }
    if (this->origin_yaw != other.origin_yaw) {
      return false;
    }
    if (this->origin_yawstd != other.origin_yawstd) {
      return false;
    }
    if (this->list_invalid_flags != other.list_invalid_flags) {
      return false;
    }
    if (this->aln_azimuth_correction != other.aln_azimuth_correction) {
      return false;
    }
    if (this->aln_elevation_correction != other.aln_elevation_correction) {
      return false;
    }
    if (this->rsv_weather != other.rsv_weather) {
      return false;
    }
    if (this->rsv_road_status != other.rsv_road_status) {
      return false;
    }
    if (this->rsv_aucc_frame_count != other.rsv_aucc_frame_count) {
      return false;
    }
    if (this->rsv_profile_id != other.rsv_profile_id) {
      return false;
    }
    if (this->rsv_adc_anti_num != other.rsv_adc_anti_num) {
      return false;
    }
    if (this->rsv_adc_real_higer_thod_cnt != other.rsv_adc_real_higer_thod_cnt) {
      return false;
    }
    if (this->rsv_adc_imag_higer_thod_cnt != other.rsv_adc_imag_higer_thod_cnt) {
      return false;
    }
    if (this->u_rsv_bfm_coeff_error_flag != other.u_rsv_bfm_coeff_error_flag) {
      return false;
    }
    if (this->rsv_ci_noise_median != other.rsv_ci_noise_median) {
      return false;
    }
    if (this->rsv_nci_noise_median != other.rsv_nci_noise_median) {
      return false;
    }
    if (this->rsv3 != other.rsv3) {
      return false;
    }
    if (this->list_len_of_detections != other.list_len_of_detections) {
      return false;
    }
    if (this->list_num_of_detections != other.list_num_of_detections) {
      return false;
    }
    if (this->list_detections != other.list_detections) {
      return false;
    }
    return true;
  }
  bool operator!=(const DetectionList_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct DetectionList_

// alias to use template instance with default allocator
using DetectionList =
  radar_msgs::msg::DetectionList_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__DETECTION_LIST__STRUCT_HPP_
