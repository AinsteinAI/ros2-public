// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from radar_msgs:msg\Detection.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__DETECTION__STRUCT_HPP_
#define RADAR_MSGS__MSG__DETAIL__DETECTION__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__radar_msgs__msg__Detection __attribute__((deprecated))
#else
# define DEPRECATED__radar_msgs__msg__Detection __declspec(deprecated)
#endif

namespace radar_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct Detection_
{
  using Type = Detection_<ContainerAllocator>;

  explicit Detection_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->measurement_id = 0;
      this->azimuth_angle = 0.0f;
      this->azimuth_angle_std = 0.0f;
      this->invalid_flags = 0;
      this->elevation_angle = 0.0f;
      this->elevation_angle_std = 0.0f;
      this->range = 0.0f;
      this->range_std = 0.0f;
      this->range_rate = 0.0f;
      this->range_rate_std = 0.0f;
      this->rcs = 0;
      this->snr = 0;
      this->positive_predictive_value = 0;
      this->classification = 0;
      this->ambiguity_flag = 0;
    }
  }

  explicit Detection_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->measurement_id = 0;
      this->azimuth_angle = 0.0f;
      this->azimuth_angle_std = 0.0f;
      this->invalid_flags = 0;
      this->elevation_angle = 0.0f;
      this->elevation_angle_std = 0.0f;
      this->range = 0.0f;
      this->range_std = 0.0f;
      this->range_rate = 0.0f;
      this->range_rate_std = 0.0f;
      this->rcs = 0;
      this->snr = 0;
      this->positive_predictive_value = 0;
      this->classification = 0;
      this->ambiguity_flag = 0;
    }
  }

  // field types and members
  using _measurement_id_type =
    uint16_t;
  _measurement_id_type measurement_id;
  using _azimuth_angle_type =
    float;
  _azimuth_angle_type azimuth_angle;
  using _azimuth_angle_std_type =
    float;
  _azimuth_angle_std_type azimuth_angle_std;
  using _invalid_flags_type =
    uint8_t;
  _invalid_flags_type invalid_flags;
  using _elevation_angle_type =
    float;
  _elevation_angle_type elevation_angle;
  using _elevation_angle_std_type =
    float;
  _elevation_angle_std_type elevation_angle_std;
  using _range_type =
    float;
  _range_type range;
  using _range_std_type =
    float;
  _range_std_type range_std;
  using _range_rate_type =
    float;
  _range_rate_type range_rate;
  using _range_rate_std_type =
    float;
  _range_rate_std_type range_rate_std;
  using _rcs_type =
    int8_t;
  _rcs_type rcs;
  using _snr_type =
    int8_t;
  _snr_type snr;
  using _positive_predictive_value_type =
    uint8_t;
  _positive_predictive_value_type positive_predictive_value;
  using _classification_type =
    uint8_t;
  _classification_type classification;
  using _ambiguity_flag_type =
    uint8_t;
  _ambiguity_flag_type ambiguity_flag;

  // setters for named parameter idiom
  Type & set__measurement_id(
    const uint16_t & _arg)
  {
    this->measurement_id = _arg;
    return *this;
  }
  Type & set__azimuth_angle(
    const float & _arg)
  {
    this->azimuth_angle = _arg;
    return *this;
  }
  Type & set__azimuth_angle_std(
    const float & _arg)
  {
    this->azimuth_angle_std = _arg;
    return *this;
  }
  Type & set__invalid_flags(
    const uint8_t & _arg)
  {
    this->invalid_flags = _arg;
    return *this;
  }
  Type & set__elevation_angle(
    const float & _arg)
  {
    this->elevation_angle = _arg;
    return *this;
  }
  Type & set__elevation_angle_std(
    const float & _arg)
  {
    this->elevation_angle_std = _arg;
    return *this;
  }
  Type & set__range(
    const float & _arg)
  {
    this->range = _arg;
    return *this;
  }
  Type & set__range_std(
    const float & _arg)
  {
    this->range_std = _arg;
    return *this;
  }
  Type & set__range_rate(
    const float & _arg)
  {
    this->range_rate = _arg;
    return *this;
  }
  Type & set__range_rate_std(
    const float & _arg)
  {
    this->range_rate_std = _arg;
    return *this;
  }
  Type & set__rcs(
    const int8_t & _arg)
  {
    this->rcs = _arg;
    return *this;
  }
  Type & set__snr(
    const int8_t & _arg)
  {
    this->snr = _arg;
    return *this;
  }
  Type & set__positive_predictive_value(
    const uint8_t & _arg)
  {
    this->positive_predictive_value = _arg;
    return *this;
  }
  Type & set__classification(
    const uint8_t & _arg)
  {
    this->classification = _arg;
    return *this;
  }
  Type & set__ambiguity_flag(
    const uint8_t & _arg)
  {
    this->ambiguity_flag = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    radar_msgs::msg::Detection_<ContainerAllocator> *;
  using ConstRawPtr =
    const radar_msgs::msg::Detection_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<radar_msgs::msg::Detection_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<radar_msgs::msg::Detection_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      radar_msgs::msg::Detection_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<radar_msgs::msg::Detection_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      radar_msgs::msg::Detection_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<radar_msgs::msg::Detection_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<radar_msgs::msg::Detection_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<radar_msgs::msg::Detection_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__radar_msgs__msg__Detection
    std::shared_ptr<radar_msgs::msg::Detection_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__radar_msgs__msg__Detection
    std::shared_ptr<radar_msgs::msg::Detection_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const Detection_ & other) const
  {
    if (this->measurement_id != other.measurement_id) {
      return false;
    }
    if (this->azimuth_angle != other.azimuth_angle) {
      return false;
    }
    if (this->azimuth_angle_std != other.azimuth_angle_std) {
      return false;
    }
    if (this->invalid_flags != other.invalid_flags) {
      return false;
    }
    if (this->elevation_angle != other.elevation_angle) {
      return false;
    }
    if (this->elevation_angle_std != other.elevation_angle_std) {
      return false;
    }
    if (this->range != other.range) {
      return false;
    }
    if (this->range_std != other.range_std) {
      return false;
    }
    if (this->range_rate != other.range_rate) {
      return false;
    }
    if (this->range_rate_std != other.range_rate_std) {
      return false;
    }
    if (this->rcs != other.rcs) {
      return false;
    }
    if (this->snr != other.snr) {
      return false;
    }
    if (this->positive_predictive_value != other.positive_predictive_value) {
      return false;
    }
    if (this->classification != other.classification) {
      return false;
    }
    if (this->ambiguity_flag != other.ambiguity_flag) {
      return false;
    }
    return true;
  }
  bool operator!=(const Detection_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct Detection_

// alias to use template instance with default allocator
using Detection =
  radar_msgs::msg::Detection_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__DETECTION__STRUCT_HPP_
