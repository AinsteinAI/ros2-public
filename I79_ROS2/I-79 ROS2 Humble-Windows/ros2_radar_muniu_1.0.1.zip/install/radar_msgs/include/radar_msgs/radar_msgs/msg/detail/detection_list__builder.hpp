// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from radar_msgs:msg\DetectionList.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__DETECTION_LIST__BUILDER_HPP_
#define RADAR_MSGS__MSG__DETAIL__DETECTION_LIST__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "radar_msgs/msg/detail/detection_list__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace radar_msgs
{

namespace msg
{

namespace builder
{

class Init_DetectionList_list_detections
{
public:
  explicit Init_DetectionList_list_detections(::radar_msgs::msg::DetectionList & msg)
  : msg_(msg)
  {}
  ::radar_msgs::msg::DetectionList list_detections(::radar_msgs::msg::DetectionList::_list_detections_type arg)
  {
    msg_.list_detections = std::move(arg);
    return std::move(msg_);
  }

private:
  ::radar_msgs::msg::DetectionList msg_;
};

class Init_DetectionList_list_num_of_detections
{
public:
  explicit Init_DetectionList_list_num_of_detections(::radar_msgs::msg::DetectionList & msg)
  : msg_(msg)
  {}
  Init_DetectionList_list_detections list_num_of_detections(::radar_msgs::msg::DetectionList::_list_num_of_detections_type arg)
  {
    msg_.list_num_of_detections = std::move(arg);
    return Init_DetectionList_list_detections(msg_);
  }

private:
  ::radar_msgs::msg::DetectionList msg_;
};

class Init_DetectionList_list_len_of_detections
{
public:
  explicit Init_DetectionList_list_len_of_detections(::radar_msgs::msg::DetectionList & msg)
  : msg_(msg)
  {}
  Init_DetectionList_list_num_of_detections list_len_of_detections(::radar_msgs::msg::DetectionList::_list_len_of_detections_type arg)
  {
    msg_.list_len_of_detections = std::move(arg);
    return Init_DetectionList_list_num_of_detections(msg_);
  }

private:
  ::radar_msgs::msg::DetectionList msg_;
};

class Init_DetectionList_rsv3
{
public:
  explicit Init_DetectionList_rsv3(::radar_msgs::msg::DetectionList & msg)
  : msg_(msg)
  {}
  Init_DetectionList_list_len_of_detections rsv3(::radar_msgs::msg::DetectionList::_rsv3_type arg)
  {
    msg_.rsv3 = std::move(arg);
    return Init_DetectionList_list_len_of_detections(msg_);
  }

private:
  ::radar_msgs::msg::DetectionList msg_;
};

class Init_DetectionList_rsv_nci_noise_median
{
public:
  explicit Init_DetectionList_rsv_nci_noise_median(::radar_msgs::msg::DetectionList & msg)
  : msg_(msg)
  {}
  Init_DetectionList_rsv3 rsv_nci_noise_median(::radar_msgs::msg::DetectionList::_rsv_nci_noise_median_type arg)
  {
    msg_.rsv_nci_noise_median = std::move(arg);
    return Init_DetectionList_rsv3(msg_);
  }

private:
  ::radar_msgs::msg::DetectionList msg_;
};

class Init_DetectionList_rsv_ci_noise_median
{
public:
  explicit Init_DetectionList_rsv_ci_noise_median(::radar_msgs::msg::DetectionList & msg)
  : msg_(msg)
  {}
  Init_DetectionList_rsv_nci_noise_median rsv_ci_noise_median(::radar_msgs::msg::DetectionList::_rsv_ci_noise_median_type arg)
  {
    msg_.rsv_ci_noise_median = std::move(arg);
    return Init_DetectionList_rsv_nci_noise_median(msg_);
  }

private:
  ::radar_msgs::msg::DetectionList msg_;
};

class Init_DetectionList_u_rsv_bfm_coeff_error_flag
{
public:
  explicit Init_DetectionList_u_rsv_bfm_coeff_error_flag(::radar_msgs::msg::DetectionList & msg)
  : msg_(msg)
  {}
  Init_DetectionList_rsv_ci_noise_median u_rsv_bfm_coeff_error_flag(::radar_msgs::msg::DetectionList::_u_rsv_bfm_coeff_error_flag_type arg)
  {
    msg_.u_rsv_bfm_coeff_error_flag = std::move(arg);
    return Init_DetectionList_rsv_ci_noise_median(msg_);
  }

private:
  ::radar_msgs::msg::DetectionList msg_;
};

class Init_DetectionList_rsv_adc_imag_higer_thod_cnt
{
public:
  explicit Init_DetectionList_rsv_adc_imag_higer_thod_cnt(::radar_msgs::msg::DetectionList & msg)
  : msg_(msg)
  {}
  Init_DetectionList_u_rsv_bfm_coeff_error_flag rsv_adc_imag_higer_thod_cnt(::radar_msgs::msg::DetectionList::_rsv_adc_imag_higer_thod_cnt_type arg)
  {
    msg_.rsv_adc_imag_higer_thod_cnt = std::move(arg);
    return Init_DetectionList_u_rsv_bfm_coeff_error_flag(msg_);
  }

private:
  ::radar_msgs::msg::DetectionList msg_;
};

class Init_DetectionList_rsv_adc_real_higer_thod_cnt
{
public:
  explicit Init_DetectionList_rsv_adc_real_higer_thod_cnt(::radar_msgs::msg::DetectionList & msg)
  : msg_(msg)
  {}
  Init_DetectionList_rsv_adc_imag_higer_thod_cnt rsv_adc_real_higer_thod_cnt(::radar_msgs::msg::DetectionList::_rsv_adc_real_higer_thod_cnt_type arg)
  {
    msg_.rsv_adc_real_higer_thod_cnt = std::move(arg);
    return Init_DetectionList_rsv_adc_imag_higer_thod_cnt(msg_);
  }

private:
  ::radar_msgs::msg::DetectionList msg_;
};

class Init_DetectionList_rsv_adc_anti_num
{
public:
  explicit Init_DetectionList_rsv_adc_anti_num(::radar_msgs::msg::DetectionList & msg)
  : msg_(msg)
  {}
  Init_DetectionList_rsv_adc_real_higer_thod_cnt rsv_adc_anti_num(::radar_msgs::msg::DetectionList::_rsv_adc_anti_num_type arg)
  {
    msg_.rsv_adc_anti_num = std::move(arg);
    return Init_DetectionList_rsv_adc_real_higer_thod_cnt(msg_);
  }

private:
  ::radar_msgs::msg::DetectionList msg_;
};

class Init_DetectionList_rsv_profile_id
{
public:
  explicit Init_DetectionList_rsv_profile_id(::radar_msgs::msg::DetectionList & msg)
  : msg_(msg)
  {}
  Init_DetectionList_rsv_adc_anti_num rsv_profile_id(::radar_msgs::msg::DetectionList::_rsv_profile_id_type arg)
  {
    msg_.rsv_profile_id = std::move(arg);
    return Init_DetectionList_rsv_adc_anti_num(msg_);
  }

private:
  ::radar_msgs::msg::DetectionList msg_;
};

class Init_DetectionList_rsv_aucc_frame_count
{
public:
  explicit Init_DetectionList_rsv_aucc_frame_count(::radar_msgs::msg::DetectionList & msg)
  : msg_(msg)
  {}
  Init_DetectionList_rsv_profile_id rsv_aucc_frame_count(::radar_msgs::msg::DetectionList::_rsv_aucc_frame_count_type arg)
  {
    msg_.rsv_aucc_frame_count = std::move(arg);
    return Init_DetectionList_rsv_profile_id(msg_);
  }

private:
  ::radar_msgs::msg::DetectionList msg_;
};

class Init_DetectionList_rsv_road_status
{
public:
  explicit Init_DetectionList_rsv_road_status(::radar_msgs::msg::DetectionList & msg)
  : msg_(msg)
  {}
  Init_DetectionList_rsv_aucc_frame_count rsv_road_status(::radar_msgs::msg::DetectionList::_rsv_road_status_type arg)
  {
    msg_.rsv_road_status = std::move(arg);
    return Init_DetectionList_rsv_aucc_frame_count(msg_);
  }

private:
  ::radar_msgs::msg::DetectionList msg_;
};

class Init_DetectionList_rsv_weather
{
public:
  explicit Init_DetectionList_rsv_weather(::radar_msgs::msg::DetectionList & msg)
  : msg_(msg)
  {}
  Init_DetectionList_rsv_road_status rsv_weather(::radar_msgs::msg::DetectionList::_rsv_weather_type arg)
  {
    msg_.rsv_weather = std::move(arg);
    return Init_DetectionList_rsv_road_status(msg_);
  }

private:
  ::radar_msgs::msg::DetectionList msg_;
};

class Init_DetectionList_aln_elevation_correction
{
public:
  explicit Init_DetectionList_aln_elevation_correction(::radar_msgs::msg::DetectionList & msg)
  : msg_(msg)
  {}
  Init_DetectionList_rsv_weather aln_elevation_correction(::radar_msgs::msg::DetectionList::_aln_elevation_correction_type arg)
  {
    msg_.aln_elevation_correction = std::move(arg);
    return Init_DetectionList_rsv_weather(msg_);
  }

private:
  ::radar_msgs::msg::DetectionList msg_;
};

class Init_DetectionList_aln_azimuth_correction
{
public:
  explicit Init_DetectionList_aln_azimuth_correction(::radar_msgs::msg::DetectionList & msg)
  : msg_(msg)
  {}
  Init_DetectionList_aln_elevation_correction aln_azimuth_correction(::radar_msgs::msg::DetectionList::_aln_azimuth_correction_type arg)
  {
    msg_.aln_azimuth_correction = std::move(arg);
    return Init_DetectionList_aln_elevation_correction(msg_);
  }

private:
  ::radar_msgs::msg::DetectionList msg_;
};

class Init_DetectionList_list_invalid_flags
{
public:
  explicit Init_DetectionList_list_invalid_flags(::radar_msgs::msg::DetectionList & msg)
  : msg_(msg)
  {}
  Init_DetectionList_aln_azimuth_correction list_invalid_flags(::radar_msgs::msg::DetectionList::_list_invalid_flags_type arg)
  {
    msg_.list_invalid_flags = std::move(arg);
    return Init_DetectionList_aln_azimuth_correction(msg_);
  }

private:
  ::radar_msgs::msg::DetectionList msg_;
};

class Init_DetectionList_origin_yawstd
{
public:
  explicit Init_DetectionList_origin_yawstd(::radar_msgs::msg::DetectionList & msg)
  : msg_(msg)
  {}
  Init_DetectionList_list_invalid_flags origin_yawstd(::radar_msgs::msg::DetectionList::_origin_yawstd_type arg)
  {
    msg_.origin_yawstd = std::move(arg);
    return Init_DetectionList_list_invalid_flags(msg_);
  }

private:
  ::radar_msgs::msg::DetectionList msg_;
};

class Init_DetectionList_origin_yaw
{
public:
  explicit Init_DetectionList_origin_yaw(::radar_msgs::msg::DetectionList & msg)
  : msg_(msg)
  {}
  Init_DetectionList_origin_yawstd origin_yaw(::radar_msgs::msg::DetectionList::_origin_yaw_type arg)
  {
    msg_.origin_yaw = std::move(arg);
    return Init_DetectionList_origin_yawstd(msg_);
  }

private:
  ::radar_msgs::msg::DetectionList msg_;
};

class Init_DetectionList_origin_pitchstd
{
public:
  explicit Init_DetectionList_origin_pitchstd(::radar_msgs::msg::DetectionList & msg)
  : msg_(msg)
  {}
  Init_DetectionList_origin_yaw origin_pitchstd(::radar_msgs::msg::DetectionList::_origin_pitchstd_type arg)
  {
    msg_.origin_pitchstd = std::move(arg);
    return Init_DetectionList_origin_yaw(msg_);
  }

private:
  ::radar_msgs::msg::DetectionList msg_;
};

class Init_DetectionList_origin_pitch
{
public:
  explicit Init_DetectionList_origin_pitch(::radar_msgs::msg::DetectionList & msg)
  : msg_(msg)
  {}
  Init_DetectionList_origin_pitchstd origin_pitch(::radar_msgs::msg::DetectionList::_origin_pitch_type arg)
  {
    msg_.origin_pitch = std::move(arg);
    return Init_DetectionList_origin_pitchstd(msg_);
  }

private:
  ::radar_msgs::msg::DetectionList msg_;
};

class Init_DetectionList_origin_rollstd
{
public:
  explicit Init_DetectionList_origin_rollstd(::radar_msgs::msg::DetectionList & msg)
  : msg_(msg)
  {}
  Init_DetectionList_origin_pitch origin_rollstd(::radar_msgs::msg::DetectionList::_origin_rollstd_type arg)
  {
    msg_.origin_rollstd = std::move(arg);
    return Init_DetectionList_origin_pitch(msg_);
  }

private:
  ::radar_msgs::msg::DetectionList msg_;
};

class Init_DetectionList_origin_roll
{
public:
  explicit Init_DetectionList_origin_roll(::radar_msgs::msg::DetectionList & msg)
  : msg_(msg)
  {}
  Init_DetectionList_origin_rollstd origin_roll(::radar_msgs::msg::DetectionList::_origin_roll_type arg)
  {
    msg_.origin_roll = std::move(arg);
    return Init_DetectionList_origin_rollstd(msg_);
  }

private:
  ::radar_msgs::msg::DetectionList msg_;
};

class Init_DetectionList_origin_zstd
{
public:
  explicit Init_DetectionList_origin_zstd(::radar_msgs::msg::DetectionList & msg)
  : msg_(msg)
  {}
  Init_DetectionList_origin_roll origin_zstd(::radar_msgs::msg::DetectionList::_origin_zstd_type arg)
  {
    msg_.origin_zstd = std::move(arg);
    return Init_DetectionList_origin_roll(msg_);
  }

private:
  ::radar_msgs::msg::DetectionList msg_;
};

class Init_DetectionList_origin_zpos
{
public:
  explicit Init_DetectionList_origin_zpos(::radar_msgs::msg::DetectionList & msg)
  : msg_(msg)
  {}
  Init_DetectionList_origin_zstd origin_zpos(::radar_msgs::msg::DetectionList::_origin_zpos_type arg)
  {
    msg_.origin_zpos = std::move(arg);
    return Init_DetectionList_origin_zstd(msg_);
  }

private:
  ::radar_msgs::msg::DetectionList msg_;
};

class Init_DetectionList_origin_ystd
{
public:
  explicit Init_DetectionList_origin_ystd(::radar_msgs::msg::DetectionList & msg)
  : msg_(msg)
  {}
  Init_DetectionList_origin_zpos origin_ystd(::radar_msgs::msg::DetectionList::_origin_ystd_type arg)
  {
    msg_.origin_ystd = std::move(arg);
    return Init_DetectionList_origin_zpos(msg_);
  }

private:
  ::radar_msgs::msg::DetectionList msg_;
};

class Init_DetectionList_origin_ypos
{
public:
  explicit Init_DetectionList_origin_ypos(::radar_msgs::msg::DetectionList & msg)
  : msg_(msg)
  {}
  Init_DetectionList_origin_ystd origin_ypos(::radar_msgs::msg::DetectionList::_origin_ypos_type arg)
  {
    msg_.origin_ypos = std::move(arg);
    return Init_DetectionList_origin_ystd(msg_);
  }

private:
  ::radar_msgs::msg::DetectionList msg_;
};

class Init_DetectionList_origin_xstd
{
public:
  explicit Init_DetectionList_origin_xstd(::radar_msgs::msg::DetectionList & msg)
  : msg_(msg)
  {}
  Init_DetectionList_origin_ypos origin_xstd(::radar_msgs::msg::DetectionList::_origin_xstd_type arg)
  {
    msg_.origin_xstd = std::move(arg);
    return Init_DetectionList_origin_ypos(msg_);
  }

private:
  ::radar_msgs::msg::DetectionList msg_;
};

class Init_DetectionList_origin_xpos
{
public:
  explicit Init_DetectionList_origin_xpos(::radar_msgs::msg::DetectionList & msg)
  : msg_(msg)
  {}
  Init_DetectionList_origin_xstd origin_xpos(::radar_msgs::msg::DetectionList::_origin_xpos_type arg)
  {
    msg_.origin_xpos = std::move(arg);
    return Init_DetectionList_origin_xstd(msg_);
  }

private:
  ::radar_msgs::msg::DetectionList msg_;
};

class Init_DetectionList_origin_invalid_flags
{
public:
  explicit Init_DetectionList_origin_invalid_flags(::radar_msgs::msg::DetectionList & msg)
  : msg_(msg)
  {}
  Init_DetectionList_origin_xpos origin_invalid_flags(::radar_msgs::msg::DetectionList::_origin_invalid_flags_type arg)
  {
    msg_.origin_invalid_flags = std::move(arg);
    return Init_DetectionList_origin_xpos(msg_);
  }

private:
  ::radar_msgs::msg::DetectionList msg_;
};

class Init_DetectionList_measurement_latency
{
public:
  explicit Init_DetectionList_measurement_latency(::radar_msgs::msg::DetectionList & msg)
  : msg_(msg)
  {}
  Init_DetectionList_origin_invalid_flags measurement_latency(::radar_msgs::msg::DetectionList::_measurement_latency_type arg)
  {
    msg_.measurement_latency = std::move(arg);
    return Init_DetectionList_origin_invalid_flags(msg_);
  }

private:
  ::radar_msgs::msg::DetectionList msg_;
};

class Init_DetectionList_coordinate_system
{
public:
  explicit Init_DetectionList_coordinate_system(::radar_msgs::msg::DetectionList & msg)
  : msg_(msg)
  {}
  Init_DetectionList_measurement_latency coordinate_system(::radar_msgs::msg::DetectionList::_coordinate_system_type arg)
  {
    msg_.coordinate_system = std::move(arg);
    return Init_DetectionList_measurement_latency(msg_);
  }

private:
  ::radar_msgs::msg::DetectionList msg_;
};

class Init_DetectionList_rsv2
{
public:
  explicit Init_DetectionList_rsv2(::radar_msgs::msg::DetectionList & msg)
  : msg_(msg)
  {}
  Init_DetectionList_coordinate_system rsv2(::radar_msgs::msg::DetectionList::_rsv2_type arg)
  {
    msg_.rsv2 = std::move(arg);
    return Init_DetectionList_coordinate_system(msg_);
  }

private:
  ::radar_msgs::msg::DetectionList msg_;
};

class Init_DetectionList_rsv1
{
public:
  explicit Init_DetectionList_rsv1(::radar_msgs::msg::DetectionList & msg)
  : msg_(msg)
  {}
  Init_DetectionList_rsv2 rsv1(::radar_msgs::msg::DetectionList::_rsv1_type arg)
  {
    msg_.rsv1 = std::move(arg);
    return Init_DetectionList_rsv2(msg_);
  }

private:
  ::radar_msgs::msg::DetectionList msg_;
};

class Init_DetectionList_timestamp_sync_status
{
public:
  explicit Init_DetectionList_timestamp_sync_status(::radar_msgs::msg::DetectionList & msg)
  : msg_(msg)
  {}
  Init_DetectionList_rsv1 timestamp_sync_status(::radar_msgs::msg::DetectionList::_timestamp_sync_status_type arg)
  {
    msg_.timestamp_sync_status = std::move(arg);
    return Init_DetectionList_rsv1(msg_);
  }

private:
  ::radar_msgs::msg::DetectionList msg_;
};

class Init_DetectionList_timestamp_seconds
{
public:
  explicit Init_DetectionList_timestamp_seconds(::radar_msgs::msg::DetectionList & msg)
  : msg_(msg)
  {}
  Init_DetectionList_timestamp_sync_status timestamp_seconds(::radar_msgs::msg::DetectionList::_timestamp_seconds_type arg)
  {
    msg_.timestamp_seconds = std::move(arg);
    return Init_DetectionList_timestamp_sync_status(msg_);
  }

private:
  ::radar_msgs::msg::DetectionList msg_;
};

class Init_DetectionList_timestamp_nanoseconds
{
public:
  explicit Init_DetectionList_timestamp_nanoseconds(::radar_msgs::msg::DetectionList & msg)
  : msg_(msg)
  {}
  Init_DetectionList_timestamp_seconds timestamp_nanoseconds(::radar_msgs::msg::DetectionList::_timestamp_nanoseconds_type arg)
  {
    msg_.timestamp_nanoseconds = std::move(arg);
    return Init_DetectionList_timestamp_seconds(msg_);
  }

private:
  ::radar_msgs::msg::DetectionList msg_;
};

class Init_DetectionList_frame_period_time
{
public:
  explicit Init_DetectionList_frame_period_time(::radar_msgs::msg::DetectionList & msg)
  : msg_(msg)
  {}
  Init_DetectionList_timestamp_nanoseconds frame_period_time(::radar_msgs::msg::DetectionList::_frame_period_time_type arg)
  {
    msg_.frame_period_time = std::move(arg);
    return Init_DetectionList_timestamp_nanoseconds(msg_);
  }

private:
  ::radar_msgs::msg::DetectionList msg_;
};

class Init_DetectionList_frame_count
{
public:
  explicit Init_DetectionList_frame_count(::radar_msgs::msg::DetectionList & msg)
  : msg_(msg)
  {}
  Init_DetectionList_frame_period_time frame_count(::radar_msgs::msg::DetectionList::_frame_count_type arg)
  {
    msg_.frame_count = std::move(arg);
    return Init_DetectionList_frame_period_time(msg_);
  }

private:
  ::radar_msgs::msg::DetectionList msg_;
};

class Init_DetectionList_version_code
{
public:
  explicit Init_DetectionList_version_code(::radar_msgs::msg::DetectionList & msg)
  : msg_(msg)
  {}
  Init_DetectionList_frame_count version_code(::radar_msgs::msg::DetectionList::_version_code_type arg)
  {
    msg_.version_code = std::move(arg);
    return Init_DetectionList_frame_count(msg_);
  }

private:
  ::radar_msgs::msg::DetectionList msg_;
};

class Init_DetectionList_data_id
{
public:
  explicit Init_DetectionList_data_id(::radar_msgs::msg::DetectionList & msg)
  : msg_(msg)
  {}
  Init_DetectionList_version_code data_id(::radar_msgs::msg::DetectionList::_data_id_type arg)
  {
    msg_.data_id = std::move(arg);
    return Init_DetectionList_version_code(msg_);
  }

private:
  ::radar_msgs::msg::DetectionList msg_;
};

class Init_DetectionList_sqc
{
public:
  explicit Init_DetectionList_sqc(::radar_msgs::msg::DetectionList & msg)
  : msg_(msg)
  {}
  Init_DetectionList_data_id sqc(::radar_msgs::msg::DetectionList::_sqc_type arg)
  {
    msg_.sqc = std::move(arg);
    return Init_DetectionList_data_id(msg_);
  }

private:
  ::radar_msgs::msg::DetectionList msg_;
};

class Init_DetectionList_length
{
public:
  explicit Init_DetectionList_length(::radar_msgs::msg::DetectionList & msg)
  : msg_(msg)
  {}
  Init_DetectionList_sqc length(::radar_msgs::msg::DetectionList::_length_type arg)
  {
    msg_.length = std::move(arg);
    return Init_DetectionList_sqc(msg_);
  }

private:
  ::radar_msgs::msg::DetectionList msg_;
};

class Init_DetectionList_crc
{
public:
  explicit Init_DetectionList_crc(::radar_msgs::msg::DetectionList & msg)
  : msg_(msg)
  {}
  Init_DetectionList_length crc(::radar_msgs::msg::DetectionList::_crc_type arg)
  {
    msg_.crc = std::move(arg);
    return Init_DetectionList_length(msg_);
  }

private:
  ::radar_msgs::msg::DetectionList msg_;
};

class Init_DetectionList_header
{
public:
  Init_DetectionList_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_DetectionList_crc header(::radar_msgs::msg::DetectionList::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_DetectionList_crc(msg_);
  }

private:
  ::radar_msgs::msg::DetectionList msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::radar_msgs::msg::DetectionList>()
{
  return radar_msgs::msg::builder::Init_DetectionList_header();
}

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__DETECTION_LIST__BUILDER_HPP_
