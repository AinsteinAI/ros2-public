// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from radar_msgs:msg\Detection.idl
// generated code does not contain a copyright notice
#include "radar_msgs/msg/detail/detection__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


bool
radar_msgs__msg__Detection__init(radar_msgs__msg__Detection * msg)
{
  if (!msg) {
    return false;
  }
  // measurement_id
  // azimuth_angle
  // azimuth_angle_std
  // invalid_flags
  // elevation_angle
  // elevation_angle_std
  // range
  // range_std
  // range_rate
  // range_rate_std
  // rcs
  // snr
  // positive_predictive_value
  // classification
  // ambiguity_flag
  return true;
}

void
radar_msgs__msg__Detection__fini(radar_msgs__msg__Detection * msg)
{
  if (!msg) {
    return;
  }
  // measurement_id
  // azimuth_angle
  // azimuth_angle_std
  // invalid_flags
  // elevation_angle
  // elevation_angle_std
  // range
  // range_std
  // range_rate
  // range_rate_std
  // rcs
  // snr
  // positive_predictive_value
  // classification
  // ambiguity_flag
}

bool
radar_msgs__msg__Detection__are_equal(const radar_msgs__msg__Detection * lhs, const radar_msgs__msg__Detection * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // measurement_id
  if (lhs->measurement_id != rhs->measurement_id) {
    return false;
  }
  // azimuth_angle
  if (lhs->azimuth_angle != rhs->azimuth_angle) {
    return false;
  }
  // azimuth_angle_std
  if (lhs->azimuth_angle_std != rhs->azimuth_angle_std) {
    return false;
  }
  // invalid_flags
  if (lhs->invalid_flags != rhs->invalid_flags) {
    return false;
  }
  // elevation_angle
  if (lhs->elevation_angle != rhs->elevation_angle) {
    return false;
  }
  // elevation_angle_std
  if (lhs->elevation_angle_std != rhs->elevation_angle_std) {
    return false;
  }
  // range
  if (lhs->range != rhs->range) {
    return false;
  }
  // range_std
  if (lhs->range_std != rhs->range_std) {
    return false;
  }
  // range_rate
  if (lhs->range_rate != rhs->range_rate) {
    return false;
  }
  // range_rate_std
  if (lhs->range_rate_std != rhs->range_rate_std) {
    return false;
  }
  // rcs
  if (lhs->rcs != rhs->rcs) {
    return false;
  }
  // snr
  if (lhs->snr != rhs->snr) {
    return false;
  }
  // positive_predictive_value
  if (lhs->positive_predictive_value != rhs->positive_predictive_value) {
    return false;
  }
  // classification
  if (lhs->classification != rhs->classification) {
    return false;
  }
  // ambiguity_flag
  if (lhs->ambiguity_flag != rhs->ambiguity_flag) {
    return false;
  }
  return true;
}

bool
radar_msgs__msg__Detection__copy(
  const radar_msgs__msg__Detection * input,
  radar_msgs__msg__Detection * output)
{
  if (!input || !output) {
    return false;
  }
  // measurement_id
  output->measurement_id = input->measurement_id;
  // azimuth_angle
  output->azimuth_angle = input->azimuth_angle;
  // azimuth_angle_std
  output->azimuth_angle_std = input->azimuth_angle_std;
  // invalid_flags
  output->invalid_flags = input->invalid_flags;
  // elevation_angle
  output->elevation_angle = input->elevation_angle;
  // elevation_angle_std
  output->elevation_angle_std = input->elevation_angle_std;
  // range
  output->range = input->range;
  // range_std
  output->range_std = input->range_std;
  // range_rate
  output->range_rate = input->range_rate;
  // range_rate_std
  output->range_rate_std = input->range_rate_std;
  // rcs
  output->rcs = input->rcs;
  // snr
  output->snr = input->snr;
  // positive_predictive_value
  output->positive_predictive_value = input->positive_predictive_value;
  // classification
  output->classification = input->classification;
  // ambiguity_flag
  output->ambiguity_flag = input->ambiguity_flag;
  return true;
}

radar_msgs__msg__Detection *
radar_msgs__msg__Detection__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__Detection * msg = (radar_msgs__msg__Detection *)allocator.allocate(sizeof(radar_msgs__msg__Detection), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(radar_msgs__msg__Detection));
  bool success = radar_msgs__msg__Detection__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
radar_msgs__msg__Detection__destroy(radar_msgs__msg__Detection * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    radar_msgs__msg__Detection__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
radar_msgs__msg__Detection__Sequence__init(radar_msgs__msg__Detection__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__Detection * data = NULL;

  if (size) {
    data = (radar_msgs__msg__Detection *)allocator.zero_allocate(size, sizeof(radar_msgs__msg__Detection), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = radar_msgs__msg__Detection__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        radar_msgs__msg__Detection__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
radar_msgs__msg__Detection__Sequence__fini(radar_msgs__msg__Detection__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      radar_msgs__msg__Detection__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

radar_msgs__msg__Detection__Sequence *
radar_msgs__msg__Detection__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__Detection__Sequence * array = (radar_msgs__msg__Detection__Sequence *)allocator.allocate(sizeof(radar_msgs__msg__Detection__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = radar_msgs__msg__Detection__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
radar_msgs__msg__Detection__Sequence__destroy(radar_msgs__msg__Detection__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    radar_msgs__msg__Detection__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
radar_msgs__msg__Detection__Sequence__are_equal(const radar_msgs__msg__Detection__Sequence * lhs, const radar_msgs__msg__Detection__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!radar_msgs__msg__Detection__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
radar_msgs__msg__Detection__Sequence__copy(
  const radar_msgs__msg__Detection__Sequence * input,
  radar_msgs__msg__Detection__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(radar_msgs__msg__Detection);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    radar_msgs__msg__Detection * data =
      (radar_msgs__msg__Detection *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!radar_msgs__msg__Detection__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          radar_msgs__msg__Detection__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!radar_msgs__msg__Detection__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
