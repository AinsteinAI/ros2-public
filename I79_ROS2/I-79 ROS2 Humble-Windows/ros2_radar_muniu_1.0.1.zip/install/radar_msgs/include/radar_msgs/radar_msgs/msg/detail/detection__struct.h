// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from radar_msgs:msg\Detection.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__DETECTION__STRUCT_H_
#define RADAR_MSGS__MSG__DETAIL__DETECTION__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in msg/Detection in the package radar_msgs.
/**
  * detection
 */
typedef struct radar_msgs__msg__Detection
{
  uint16_t measurement_id;
  float azimuth_angle;
  float azimuth_angle_std;
  uint8_t invalid_flags;
  float elevation_angle;
  float elevation_angle_std;
  float range;
  float range_std;
  float range_rate;
  float range_rate_std;
  int8_t rcs;
  int8_t snr;
  uint8_t positive_predictive_value;
  uint8_t classification;
  uint8_t ambiguity_flag;
} radar_msgs__msg__Detection;

// Struct for a sequence of radar_msgs__msg__Detection.
typedef struct radar_msgs__msg__Detection__Sequence
{
  radar_msgs__msg__Detection * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} radar_msgs__msg__Detection__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // RADAR_MSGS__MSG__DETAIL__DETECTION__STRUCT_H_
