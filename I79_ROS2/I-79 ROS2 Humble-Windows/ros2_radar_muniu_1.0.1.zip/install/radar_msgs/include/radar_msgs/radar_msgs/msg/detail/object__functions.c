// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from radar_msgs:msg\Object.idl
// generated code does not contain a copyright notice
#include "radar_msgs/msg/detail/object__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


bool
radar_msgs__msg__Object__init(radar_msgs__msg__Object * msg)
{
  if (!msg) {
    return false;
  }
  // object_id
  // object_age
  // object_status_measurement
  // object_status_movement
  // position_reference
  // position_x
  // position_x_std
  // position_y
  // position_y_std
  // position_z
  // position_z_std
  // position_orientation
  // position_orientation_std
  // dynamics_vel_x
  // dynamics_vel_x_std
  // dynamics_vel_y
  // dynamics_vel_y_std
  // dynamics_vel_z
  // dynamics_vel_z_std
  // dynamics_acce_x
  // dynamics_acce_x_std
  // dynamics_acce_y
  // dynamics_acce_y_std
  // dynamics_acce_z
  // dynamics_acce_z_std
  // dynamics_orientation_rate
  // dynamics_orientation_rate_std
  // existence_prob
  // obstacle_prob
  // classification
  // classification_prob
  // shape_length_mean
  // shape_length_std
  // shape_width_mean
  // shape_width_std
  // shape_height_mean
  // shape_height_std
  return true;
}

void
radar_msgs__msg__Object__fini(radar_msgs__msg__Object * msg)
{
  if (!msg) {
    return;
  }
  // object_id
  // object_age
  // object_status_measurement
  // object_status_movement
  // position_reference
  // position_x
  // position_x_std
  // position_y
  // position_y_std
  // position_z
  // position_z_std
  // position_orientation
  // position_orientation_std
  // dynamics_vel_x
  // dynamics_vel_x_std
  // dynamics_vel_y
  // dynamics_vel_y_std
  // dynamics_vel_z
  // dynamics_vel_z_std
  // dynamics_acce_x
  // dynamics_acce_x_std
  // dynamics_acce_y
  // dynamics_acce_y_std
  // dynamics_acce_z
  // dynamics_acce_z_std
  // dynamics_orientation_rate
  // dynamics_orientation_rate_std
  // existence_prob
  // obstacle_prob
  // classification
  // classification_prob
  // shape_length_mean
  // shape_length_std
  // shape_width_mean
  // shape_width_std
  // shape_height_mean
  // shape_height_std
}

bool
radar_msgs__msg__Object__are_equal(const radar_msgs__msg__Object * lhs, const radar_msgs__msg__Object * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // object_id
  if (lhs->object_id != rhs->object_id) {
    return false;
  }
  // object_age
  if (lhs->object_age != rhs->object_age) {
    return false;
  }
  // object_status_measurement
  if (lhs->object_status_measurement != rhs->object_status_measurement) {
    return false;
  }
  // object_status_movement
  if (lhs->object_status_movement != rhs->object_status_movement) {
    return false;
  }
  // position_reference
  if (lhs->position_reference != rhs->position_reference) {
    return false;
  }
  // position_x
  if (lhs->position_x != rhs->position_x) {
    return false;
  }
  // position_x_std
  if (lhs->position_x_std != rhs->position_x_std) {
    return false;
  }
  // position_y
  if (lhs->position_y != rhs->position_y) {
    return false;
  }
  // position_y_std
  if (lhs->position_y_std != rhs->position_y_std) {
    return false;
  }
  // position_z
  if (lhs->position_z != rhs->position_z) {
    return false;
  }
  // position_z_std
  if (lhs->position_z_std != rhs->position_z_std) {
    return false;
  }
  // position_orientation
  if (lhs->position_orientation != rhs->position_orientation) {
    return false;
  }
  // position_orientation_std
  if (lhs->position_orientation_std != rhs->position_orientation_std) {
    return false;
  }
  // dynamics_vel_x
  if (lhs->dynamics_vel_x != rhs->dynamics_vel_x) {
    return false;
  }
  // dynamics_vel_x_std
  if (lhs->dynamics_vel_x_std != rhs->dynamics_vel_x_std) {
    return false;
  }
  // dynamics_vel_y
  if (lhs->dynamics_vel_y != rhs->dynamics_vel_y) {
    return false;
  }
  // dynamics_vel_y_std
  if (lhs->dynamics_vel_y_std != rhs->dynamics_vel_y_std) {
    return false;
  }
  // dynamics_vel_z
  if (lhs->dynamics_vel_z != rhs->dynamics_vel_z) {
    return false;
  }
  // dynamics_vel_z_std
  if (lhs->dynamics_vel_z_std != rhs->dynamics_vel_z_std) {
    return false;
  }
  // dynamics_acce_x
  if (lhs->dynamics_acce_x != rhs->dynamics_acce_x) {
    return false;
  }
  // dynamics_acce_x_std
  if (lhs->dynamics_acce_x_std != rhs->dynamics_acce_x_std) {
    return false;
  }
  // dynamics_acce_y
  if (lhs->dynamics_acce_y != rhs->dynamics_acce_y) {
    return false;
  }
  // dynamics_acce_y_std
  if (lhs->dynamics_acce_y_std != rhs->dynamics_acce_y_std) {
    return false;
  }
  // dynamics_acce_z
  if (lhs->dynamics_acce_z != rhs->dynamics_acce_z) {
    return false;
  }
  // dynamics_acce_z_std
  if (lhs->dynamics_acce_z_std != rhs->dynamics_acce_z_std) {
    return false;
  }
  // dynamics_orientation_rate
  if (lhs->dynamics_orientation_rate != rhs->dynamics_orientation_rate) {
    return false;
  }
  // dynamics_orientation_rate_std
  if (lhs->dynamics_orientation_rate_std != rhs->dynamics_orientation_rate_std) {
    return false;
  }
  // existence_prob
  if (lhs->existence_prob != rhs->existence_prob) {
    return false;
  }
  // obstacle_prob
  if (lhs->obstacle_prob != rhs->obstacle_prob) {
    return false;
  }
  // classification
  if (lhs->classification != rhs->classification) {
    return false;
  }
  // classification_prob
  if (lhs->classification_prob != rhs->classification_prob) {
    return false;
  }
  // shape_length_mean
  if (lhs->shape_length_mean != rhs->shape_length_mean) {
    return false;
  }
  // shape_length_std
  if (lhs->shape_length_std != rhs->shape_length_std) {
    return false;
  }
  // shape_width_mean
  if (lhs->shape_width_mean != rhs->shape_width_mean) {
    return false;
  }
  // shape_width_std
  if (lhs->shape_width_std != rhs->shape_width_std) {
    return false;
  }
  // shape_height_mean
  if (lhs->shape_height_mean != rhs->shape_height_mean) {
    return false;
  }
  // shape_height_std
  if (lhs->shape_height_std != rhs->shape_height_std) {
    return false;
  }
  return true;
}

bool
radar_msgs__msg__Object__copy(
  const radar_msgs__msg__Object * input,
  radar_msgs__msg__Object * output)
{
  if (!input || !output) {
    return false;
  }
  // object_id
  output->object_id = input->object_id;
  // object_age
  output->object_age = input->object_age;
  // object_status_measurement
  output->object_status_measurement = input->object_status_measurement;
  // object_status_movement
  output->object_status_movement = input->object_status_movement;
  // position_reference
  output->position_reference = input->position_reference;
  // position_x
  output->position_x = input->position_x;
  // position_x_std
  output->position_x_std = input->position_x_std;
  // position_y
  output->position_y = input->position_y;
  // position_y_std
  output->position_y_std = input->position_y_std;
  // position_z
  output->position_z = input->position_z;
  // position_z_std
  output->position_z_std = input->position_z_std;
  // position_orientation
  output->position_orientation = input->position_orientation;
  // position_orientation_std
  output->position_orientation_std = input->position_orientation_std;
  // dynamics_vel_x
  output->dynamics_vel_x = input->dynamics_vel_x;
  // dynamics_vel_x_std
  output->dynamics_vel_x_std = input->dynamics_vel_x_std;
  // dynamics_vel_y
  output->dynamics_vel_y = input->dynamics_vel_y;
  // dynamics_vel_y_std
  output->dynamics_vel_y_std = input->dynamics_vel_y_std;
  // dynamics_vel_z
  output->dynamics_vel_z = input->dynamics_vel_z;
  // dynamics_vel_z_std
  output->dynamics_vel_z_std = input->dynamics_vel_z_std;
  // dynamics_acce_x
  output->dynamics_acce_x = input->dynamics_acce_x;
  // dynamics_acce_x_std
  output->dynamics_acce_x_std = input->dynamics_acce_x_std;
  // dynamics_acce_y
  output->dynamics_acce_y = input->dynamics_acce_y;
  // dynamics_acce_y_std
  output->dynamics_acce_y_std = input->dynamics_acce_y_std;
  // dynamics_acce_z
  output->dynamics_acce_z = input->dynamics_acce_z;
  // dynamics_acce_z_std
  output->dynamics_acce_z_std = input->dynamics_acce_z_std;
  // dynamics_orientation_rate
  output->dynamics_orientation_rate = input->dynamics_orientation_rate;
  // dynamics_orientation_rate_std
  output->dynamics_orientation_rate_std = input->dynamics_orientation_rate_std;
  // existence_prob
  output->existence_prob = input->existence_prob;
  // obstacle_prob
  output->obstacle_prob = input->obstacle_prob;
  // classification
  output->classification = input->classification;
  // classification_prob
  output->classification_prob = input->classification_prob;
  // shape_length_mean
  output->shape_length_mean = input->shape_length_mean;
  // shape_length_std
  output->shape_length_std = input->shape_length_std;
  // shape_width_mean
  output->shape_width_mean = input->shape_width_mean;
  // shape_width_std
  output->shape_width_std = input->shape_width_std;
  // shape_height_mean
  output->shape_height_mean = input->shape_height_mean;
  // shape_height_std
  output->shape_height_std = input->shape_height_std;
  return true;
}

radar_msgs__msg__Object *
radar_msgs__msg__Object__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__Object * msg = (radar_msgs__msg__Object *)allocator.allocate(sizeof(radar_msgs__msg__Object), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(radar_msgs__msg__Object));
  bool success = radar_msgs__msg__Object__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
radar_msgs__msg__Object__destroy(radar_msgs__msg__Object * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    radar_msgs__msg__Object__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
radar_msgs__msg__Object__Sequence__init(radar_msgs__msg__Object__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__Object * data = NULL;

  if (size) {
    data = (radar_msgs__msg__Object *)allocator.zero_allocate(size, sizeof(radar_msgs__msg__Object), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = radar_msgs__msg__Object__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        radar_msgs__msg__Object__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
radar_msgs__msg__Object__Sequence__fini(radar_msgs__msg__Object__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      radar_msgs__msg__Object__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

radar_msgs__msg__Object__Sequence *
radar_msgs__msg__Object__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__Object__Sequence * array = (radar_msgs__msg__Object__Sequence *)allocator.allocate(sizeof(radar_msgs__msg__Object__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = radar_msgs__msg__Object__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
radar_msgs__msg__Object__Sequence__destroy(radar_msgs__msg__Object__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    radar_msgs__msg__Object__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
radar_msgs__msg__Object__Sequence__are_equal(const radar_msgs__msg__Object__Sequence * lhs, const radar_msgs__msg__Object__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!radar_msgs__msg__Object__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
radar_msgs__msg__Object__Sequence__copy(
  const radar_msgs__msg__Object__Sequence * input,
  radar_msgs__msg__Object__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(radar_msgs__msg__Object);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    radar_msgs__msg__Object * data =
      (radar_msgs__msg__Object *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!radar_msgs__msg__Object__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          radar_msgs__msg__Object__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!radar_msgs__msg__Object__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
