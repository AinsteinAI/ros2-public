// generated from rosidl_generator_c/resource/idl.h.em
// with input from radar_msgs:msg\ObjectList.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__OBJECT_LIST_H_
#define RADAR_MSGS__MSG__OBJECT_LIST_H_

#include "radar_msgs/msg/detail/object_list__struct.h"
#include "radar_msgs/msg/detail/object_list__functions.h"
#include "radar_msgs/msg/detail/object_list__type_support.h"

#endif  // RADAR_MSGS__MSG__OBJECT_LIST_H_
