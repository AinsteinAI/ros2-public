// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from radar_msgs:msg\Object.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__OBJECT__STRUCT_H_
#define RADAR_MSGS__MSG__DETAIL__OBJECT__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in msg/Object in the package radar_msgs.
typedef struct radar_msgs__msg__Object
{
  uint32_t object_id;
  uint16_t object_age;
  uint8_t object_status_measurement;
  uint8_t object_status_movement;
  uint8_t position_reference;
  float position_x;
  float position_x_std;
  float position_y;
  float position_y_std;
  float position_z;
  float position_z_std;
  float position_orientation;
  float position_orientation_std;
  float dynamics_vel_x;
  float dynamics_vel_x_std;
  float dynamics_vel_y;
  float dynamics_vel_y_std;
  float dynamics_vel_z;
  float dynamics_vel_z_std;
  float dynamics_acce_x;
  float dynamics_acce_x_std;
  float dynamics_acce_y;
  float dynamics_acce_y_std;
  float dynamics_acce_z;
  float dynamics_acce_z_std;
  float dynamics_orientation_rate;
  float dynamics_orientation_rate_std;
  float existence_prob;
  float obstacle_prob;
  uint8_t classification;
  uint8_t classification_prob;
  float shape_length_mean;
  float shape_length_std;
  float shape_width_mean;
  float shape_width_std;
  float shape_height_mean;
  float shape_height_std;
} radar_msgs__msg__Object;

// Struct for a sequence of radar_msgs__msg__Object.
typedef struct radar_msgs__msg__Object__Sequence
{
  radar_msgs__msg__Object * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} radar_msgs__msg__Object__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // RADAR_MSGS__MSG__DETAIL__OBJECT__STRUCT_H_
