// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from radar_msgs:msg\ObjectList.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__OBJECT_LIST__TRAITS_HPP_
#define RADAR_MSGS__MSG__DETAIL__OBJECT_LIST__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "radar_msgs/msg/detail/object_list__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"
// Member 'objectlist_objects'
#include "radar_msgs/msg/detail/object__traits.hpp"

namespace radar_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const ObjectList & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: crc
  {
    out << "crc: ";
    rosidl_generator_traits::value_to_yaml(msg.crc, out);
    out << ", ";
  }

  // member: length
  {
    out << "length: ";
    rosidl_generator_traits::value_to_yaml(msg.length, out);
    out << ", ";
  }

  // member: sqc
  {
    out << "sqc: ";
    rosidl_generator_traits::value_to_yaml(msg.sqc, out);
    out << ", ";
  }

  // member: dataid
  {
    out << "dataid: ";
    rosidl_generator_traits::value_to_yaml(msg.dataid, out);
    out << ", ";
  }

  // member: timestamp_nanoseconds
  {
    out << "timestamp_nanoseconds: ";
    rosidl_generator_traits::value_to_yaml(msg.timestamp_nanoseconds, out);
    out << ", ";
  }

  // member: timestamp_seconds
  {
    out << "timestamp_seconds: ";
    rosidl_generator_traits::value_to_yaml(msg.timestamp_seconds, out);
    out << ", ";
  }

  // member: timestamp_syncstatus
  {
    out << "timestamp_syncstatus: ";
    rosidl_generator_traits::value_to_yaml(msg.timestamp_syncstatus, out);
    out << ", ";
  }

  // member: rsv1
  {
    out << "rsv1: ";
    rosidl_generator_traits::value_to_yaml(msg.rsv1, out);
    out << ", ";
  }

  // member: rsv2
  {
    out << "rsv2: ";
    rosidl_generator_traits::value_to_yaml(msg.rsv2, out);
    out << ", ";
  }

  // member: frame_count
  {
    out << "frame_count: ";
    rosidl_generator_traits::value_to_yaml(msg.frame_count, out);
    out << ", ";
  }

  // member: coordinate_system
  {
    out << "coordinate_system: ";
    rosidl_generator_traits::value_to_yaml(msg.coordinate_system, out);
    out << ", ";
  }

  // member: measurement_latency
  {
    out << "measurement_latency: ";
    rosidl_generator_traits::value_to_yaml(msg.measurement_latency, out);
    out << ", ";
  }

  // member: rsv3
  {
    if (msg.rsv3.size() == 0) {
      out << "rsv3: []";
    } else {
      out << "rsv3: [";
      size_t pending_items = msg.rsv3.size();
      for (auto item : msg.rsv3) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: objectlist_numofobjects
  {
    out << "objectlist_numofobjects: ";
    rosidl_generator_traits::value_to_yaml(msg.objectlist_numofobjects, out);
    out << ", ";
  }

  // member: objectlist_objects
  {
    if (msg.objectlist_objects.size() == 0) {
      out << "objectlist_objects: []";
    } else {
      out << "objectlist_objects: [";
      size_t pending_items = msg.objectlist_objects.size();
      for (auto item : msg.objectlist_objects) {
        to_flow_style_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ObjectList & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: crc
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "crc: ";
    rosidl_generator_traits::value_to_yaml(msg.crc, out);
    out << "\n";
  }

  // member: length
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "length: ";
    rosidl_generator_traits::value_to_yaml(msg.length, out);
    out << "\n";
  }

  // member: sqc
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "sqc: ";
    rosidl_generator_traits::value_to_yaml(msg.sqc, out);
    out << "\n";
  }

  // member: dataid
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "dataid: ";
    rosidl_generator_traits::value_to_yaml(msg.dataid, out);
    out << "\n";
  }

  // member: timestamp_nanoseconds
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "timestamp_nanoseconds: ";
    rosidl_generator_traits::value_to_yaml(msg.timestamp_nanoseconds, out);
    out << "\n";
  }

  // member: timestamp_seconds
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "timestamp_seconds: ";
    rosidl_generator_traits::value_to_yaml(msg.timestamp_seconds, out);
    out << "\n";
  }

  // member: timestamp_syncstatus
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "timestamp_syncstatus: ";
    rosidl_generator_traits::value_to_yaml(msg.timestamp_syncstatus, out);
    out << "\n";
  }

  // member: rsv1
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "rsv1: ";
    rosidl_generator_traits::value_to_yaml(msg.rsv1, out);
    out << "\n";
  }

  // member: rsv2
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "rsv2: ";
    rosidl_generator_traits::value_to_yaml(msg.rsv2, out);
    out << "\n";
  }

  // member: frame_count
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "frame_count: ";
    rosidl_generator_traits::value_to_yaml(msg.frame_count, out);
    out << "\n";
  }

  // member: coordinate_system
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "coordinate_system: ";
    rosidl_generator_traits::value_to_yaml(msg.coordinate_system, out);
    out << "\n";
  }

  // member: measurement_latency
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "measurement_latency: ";
    rosidl_generator_traits::value_to_yaml(msg.measurement_latency, out);
    out << "\n";
  }

  // member: rsv3
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.rsv3.size() == 0) {
      out << "rsv3: []\n";
    } else {
      out << "rsv3:\n";
      for (auto item : msg.rsv3) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: objectlist_numofobjects
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "objectlist_numofobjects: ";
    rosidl_generator_traits::value_to_yaml(msg.objectlist_numofobjects, out);
    out << "\n";
  }

  // member: objectlist_objects
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.objectlist_objects.size() == 0) {
      out << "objectlist_objects: []\n";
    } else {
      out << "objectlist_objects:\n";
      for (auto item : msg.objectlist_objects) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_block_style_yaml(item, out, indentation + 2);
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ObjectList & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace radar_msgs

namespace rosidl_generator_traits
{

[[deprecated("use radar_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const radar_msgs::msg::ObjectList & msg,
  std::ostream & out, size_t indentation = 0)
{
  radar_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use radar_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const radar_msgs::msg::ObjectList & msg)
{
  return radar_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<radar_msgs::msg::ObjectList>()
{
  return "radar_msgs::msg::ObjectList";
}

template<>
inline const char * name<radar_msgs::msg::ObjectList>()
{
  return "radar_msgs/msg/ObjectList";
}

template<>
struct has_fixed_size<radar_msgs::msg::ObjectList>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<radar_msgs::msg::ObjectList>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<radar_msgs::msg::ObjectList>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // RADAR_MSGS__MSG__DETAIL__OBJECT_LIST__TRAITS_HPP_
