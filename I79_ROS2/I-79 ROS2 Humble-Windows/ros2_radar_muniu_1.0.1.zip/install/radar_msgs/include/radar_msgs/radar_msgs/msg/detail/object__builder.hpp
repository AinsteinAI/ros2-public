// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from radar_msgs:msg\Object.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__OBJECT__BUILDER_HPP_
#define RADAR_MSGS__MSG__DETAIL__OBJECT__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "radar_msgs/msg/detail/object__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace radar_msgs
{

namespace msg
{

namespace builder
{

class Init_Object_shape_height_std
{
public:
  explicit Init_Object_shape_height_std(::radar_msgs::msg::Object & msg)
  : msg_(msg)
  {}
  ::radar_msgs::msg::Object shape_height_std(::radar_msgs::msg::Object::_shape_height_std_type arg)
  {
    msg_.shape_height_std = std::move(arg);
    return std::move(msg_);
  }

private:
  ::radar_msgs::msg::Object msg_;
};

class Init_Object_shape_height_mean
{
public:
  explicit Init_Object_shape_height_mean(::radar_msgs::msg::Object & msg)
  : msg_(msg)
  {}
  Init_Object_shape_height_std shape_height_mean(::radar_msgs::msg::Object::_shape_height_mean_type arg)
  {
    msg_.shape_height_mean = std::move(arg);
    return Init_Object_shape_height_std(msg_);
  }

private:
  ::radar_msgs::msg::Object msg_;
};

class Init_Object_shape_width_std
{
public:
  explicit Init_Object_shape_width_std(::radar_msgs::msg::Object & msg)
  : msg_(msg)
  {}
  Init_Object_shape_height_mean shape_width_std(::radar_msgs::msg::Object::_shape_width_std_type arg)
  {
    msg_.shape_width_std = std::move(arg);
    return Init_Object_shape_height_mean(msg_);
  }

private:
  ::radar_msgs::msg::Object msg_;
};

class Init_Object_shape_width_mean
{
public:
  explicit Init_Object_shape_width_mean(::radar_msgs::msg::Object & msg)
  : msg_(msg)
  {}
  Init_Object_shape_width_std shape_width_mean(::radar_msgs::msg::Object::_shape_width_mean_type arg)
  {
    msg_.shape_width_mean = std::move(arg);
    return Init_Object_shape_width_std(msg_);
  }

private:
  ::radar_msgs::msg::Object msg_;
};

class Init_Object_shape_length_std
{
public:
  explicit Init_Object_shape_length_std(::radar_msgs::msg::Object & msg)
  : msg_(msg)
  {}
  Init_Object_shape_width_mean shape_length_std(::radar_msgs::msg::Object::_shape_length_std_type arg)
  {
    msg_.shape_length_std = std::move(arg);
    return Init_Object_shape_width_mean(msg_);
  }

private:
  ::radar_msgs::msg::Object msg_;
};

class Init_Object_shape_length_mean
{
public:
  explicit Init_Object_shape_length_mean(::radar_msgs::msg::Object & msg)
  : msg_(msg)
  {}
  Init_Object_shape_length_std shape_length_mean(::radar_msgs::msg::Object::_shape_length_mean_type arg)
  {
    msg_.shape_length_mean = std::move(arg);
    return Init_Object_shape_length_std(msg_);
  }

private:
  ::radar_msgs::msg::Object msg_;
};

class Init_Object_classification_prob
{
public:
  explicit Init_Object_classification_prob(::radar_msgs::msg::Object & msg)
  : msg_(msg)
  {}
  Init_Object_shape_length_mean classification_prob(::radar_msgs::msg::Object::_classification_prob_type arg)
  {
    msg_.classification_prob = std::move(arg);
    return Init_Object_shape_length_mean(msg_);
  }

private:
  ::radar_msgs::msg::Object msg_;
};

class Init_Object_classification
{
public:
  explicit Init_Object_classification(::radar_msgs::msg::Object & msg)
  : msg_(msg)
  {}
  Init_Object_classification_prob classification(::radar_msgs::msg::Object::_classification_type arg)
  {
    msg_.classification = std::move(arg);
    return Init_Object_classification_prob(msg_);
  }

private:
  ::radar_msgs::msg::Object msg_;
};

class Init_Object_obstacle_prob
{
public:
  explicit Init_Object_obstacle_prob(::radar_msgs::msg::Object & msg)
  : msg_(msg)
  {}
  Init_Object_classification obstacle_prob(::radar_msgs::msg::Object::_obstacle_prob_type arg)
  {
    msg_.obstacle_prob = std::move(arg);
    return Init_Object_classification(msg_);
  }

private:
  ::radar_msgs::msg::Object msg_;
};

class Init_Object_existence_prob
{
public:
  explicit Init_Object_existence_prob(::radar_msgs::msg::Object & msg)
  : msg_(msg)
  {}
  Init_Object_obstacle_prob existence_prob(::radar_msgs::msg::Object::_existence_prob_type arg)
  {
    msg_.existence_prob = std::move(arg);
    return Init_Object_obstacle_prob(msg_);
  }

private:
  ::radar_msgs::msg::Object msg_;
};

class Init_Object_dynamics_orientation_rate_std
{
public:
  explicit Init_Object_dynamics_orientation_rate_std(::radar_msgs::msg::Object & msg)
  : msg_(msg)
  {}
  Init_Object_existence_prob dynamics_orientation_rate_std(::radar_msgs::msg::Object::_dynamics_orientation_rate_std_type arg)
  {
    msg_.dynamics_orientation_rate_std = std::move(arg);
    return Init_Object_existence_prob(msg_);
  }

private:
  ::radar_msgs::msg::Object msg_;
};

class Init_Object_dynamics_orientation_rate
{
public:
  explicit Init_Object_dynamics_orientation_rate(::radar_msgs::msg::Object & msg)
  : msg_(msg)
  {}
  Init_Object_dynamics_orientation_rate_std dynamics_orientation_rate(::radar_msgs::msg::Object::_dynamics_orientation_rate_type arg)
  {
    msg_.dynamics_orientation_rate = std::move(arg);
    return Init_Object_dynamics_orientation_rate_std(msg_);
  }

private:
  ::radar_msgs::msg::Object msg_;
};

class Init_Object_dynamics_acce_z_std
{
public:
  explicit Init_Object_dynamics_acce_z_std(::radar_msgs::msg::Object & msg)
  : msg_(msg)
  {}
  Init_Object_dynamics_orientation_rate dynamics_acce_z_std(::radar_msgs::msg::Object::_dynamics_acce_z_std_type arg)
  {
    msg_.dynamics_acce_z_std = std::move(arg);
    return Init_Object_dynamics_orientation_rate(msg_);
  }

private:
  ::radar_msgs::msg::Object msg_;
};

class Init_Object_dynamics_acce_z
{
public:
  explicit Init_Object_dynamics_acce_z(::radar_msgs::msg::Object & msg)
  : msg_(msg)
  {}
  Init_Object_dynamics_acce_z_std dynamics_acce_z(::radar_msgs::msg::Object::_dynamics_acce_z_type arg)
  {
    msg_.dynamics_acce_z = std::move(arg);
    return Init_Object_dynamics_acce_z_std(msg_);
  }

private:
  ::radar_msgs::msg::Object msg_;
};

class Init_Object_dynamics_acce_y_std
{
public:
  explicit Init_Object_dynamics_acce_y_std(::radar_msgs::msg::Object & msg)
  : msg_(msg)
  {}
  Init_Object_dynamics_acce_z dynamics_acce_y_std(::radar_msgs::msg::Object::_dynamics_acce_y_std_type arg)
  {
    msg_.dynamics_acce_y_std = std::move(arg);
    return Init_Object_dynamics_acce_z(msg_);
  }

private:
  ::radar_msgs::msg::Object msg_;
};

class Init_Object_dynamics_acce_y
{
public:
  explicit Init_Object_dynamics_acce_y(::radar_msgs::msg::Object & msg)
  : msg_(msg)
  {}
  Init_Object_dynamics_acce_y_std dynamics_acce_y(::radar_msgs::msg::Object::_dynamics_acce_y_type arg)
  {
    msg_.dynamics_acce_y = std::move(arg);
    return Init_Object_dynamics_acce_y_std(msg_);
  }

private:
  ::radar_msgs::msg::Object msg_;
};

class Init_Object_dynamics_acce_x_std
{
public:
  explicit Init_Object_dynamics_acce_x_std(::radar_msgs::msg::Object & msg)
  : msg_(msg)
  {}
  Init_Object_dynamics_acce_y dynamics_acce_x_std(::radar_msgs::msg::Object::_dynamics_acce_x_std_type arg)
  {
    msg_.dynamics_acce_x_std = std::move(arg);
    return Init_Object_dynamics_acce_y(msg_);
  }

private:
  ::radar_msgs::msg::Object msg_;
};

class Init_Object_dynamics_acce_x
{
public:
  explicit Init_Object_dynamics_acce_x(::radar_msgs::msg::Object & msg)
  : msg_(msg)
  {}
  Init_Object_dynamics_acce_x_std dynamics_acce_x(::radar_msgs::msg::Object::_dynamics_acce_x_type arg)
  {
    msg_.dynamics_acce_x = std::move(arg);
    return Init_Object_dynamics_acce_x_std(msg_);
  }

private:
  ::radar_msgs::msg::Object msg_;
};

class Init_Object_dynamics_vel_z_std
{
public:
  explicit Init_Object_dynamics_vel_z_std(::radar_msgs::msg::Object & msg)
  : msg_(msg)
  {}
  Init_Object_dynamics_acce_x dynamics_vel_z_std(::radar_msgs::msg::Object::_dynamics_vel_z_std_type arg)
  {
    msg_.dynamics_vel_z_std = std::move(arg);
    return Init_Object_dynamics_acce_x(msg_);
  }

private:
  ::radar_msgs::msg::Object msg_;
};

class Init_Object_dynamics_vel_z
{
public:
  explicit Init_Object_dynamics_vel_z(::radar_msgs::msg::Object & msg)
  : msg_(msg)
  {}
  Init_Object_dynamics_vel_z_std dynamics_vel_z(::radar_msgs::msg::Object::_dynamics_vel_z_type arg)
  {
    msg_.dynamics_vel_z = std::move(arg);
    return Init_Object_dynamics_vel_z_std(msg_);
  }

private:
  ::radar_msgs::msg::Object msg_;
};

class Init_Object_dynamics_vel_y_std
{
public:
  explicit Init_Object_dynamics_vel_y_std(::radar_msgs::msg::Object & msg)
  : msg_(msg)
  {}
  Init_Object_dynamics_vel_z dynamics_vel_y_std(::radar_msgs::msg::Object::_dynamics_vel_y_std_type arg)
  {
    msg_.dynamics_vel_y_std = std::move(arg);
    return Init_Object_dynamics_vel_z(msg_);
  }

private:
  ::radar_msgs::msg::Object msg_;
};

class Init_Object_dynamics_vel_y
{
public:
  explicit Init_Object_dynamics_vel_y(::radar_msgs::msg::Object & msg)
  : msg_(msg)
  {}
  Init_Object_dynamics_vel_y_std dynamics_vel_y(::radar_msgs::msg::Object::_dynamics_vel_y_type arg)
  {
    msg_.dynamics_vel_y = std::move(arg);
    return Init_Object_dynamics_vel_y_std(msg_);
  }

private:
  ::radar_msgs::msg::Object msg_;
};

class Init_Object_dynamics_vel_x_std
{
public:
  explicit Init_Object_dynamics_vel_x_std(::radar_msgs::msg::Object & msg)
  : msg_(msg)
  {}
  Init_Object_dynamics_vel_y dynamics_vel_x_std(::radar_msgs::msg::Object::_dynamics_vel_x_std_type arg)
  {
    msg_.dynamics_vel_x_std = std::move(arg);
    return Init_Object_dynamics_vel_y(msg_);
  }

private:
  ::radar_msgs::msg::Object msg_;
};

class Init_Object_dynamics_vel_x
{
public:
  explicit Init_Object_dynamics_vel_x(::radar_msgs::msg::Object & msg)
  : msg_(msg)
  {}
  Init_Object_dynamics_vel_x_std dynamics_vel_x(::radar_msgs::msg::Object::_dynamics_vel_x_type arg)
  {
    msg_.dynamics_vel_x = std::move(arg);
    return Init_Object_dynamics_vel_x_std(msg_);
  }

private:
  ::radar_msgs::msg::Object msg_;
};

class Init_Object_position_orientation_std
{
public:
  explicit Init_Object_position_orientation_std(::radar_msgs::msg::Object & msg)
  : msg_(msg)
  {}
  Init_Object_dynamics_vel_x position_orientation_std(::radar_msgs::msg::Object::_position_orientation_std_type arg)
  {
    msg_.position_orientation_std = std::move(arg);
    return Init_Object_dynamics_vel_x(msg_);
  }

private:
  ::radar_msgs::msg::Object msg_;
};

class Init_Object_position_orientation
{
public:
  explicit Init_Object_position_orientation(::radar_msgs::msg::Object & msg)
  : msg_(msg)
  {}
  Init_Object_position_orientation_std position_orientation(::radar_msgs::msg::Object::_position_orientation_type arg)
  {
    msg_.position_orientation = std::move(arg);
    return Init_Object_position_orientation_std(msg_);
  }

private:
  ::radar_msgs::msg::Object msg_;
};

class Init_Object_position_z_std
{
public:
  explicit Init_Object_position_z_std(::radar_msgs::msg::Object & msg)
  : msg_(msg)
  {}
  Init_Object_position_orientation position_z_std(::radar_msgs::msg::Object::_position_z_std_type arg)
  {
    msg_.position_z_std = std::move(arg);
    return Init_Object_position_orientation(msg_);
  }

private:
  ::radar_msgs::msg::Object msg_;
};

class Init_Object_position_z
{
public:
  explicit Init_Object_position_z(::radar_msgs::msg::Object & msg)
  : msg_(msg)
  {}
  Init_Object_position_z_std position_z(::radar_msgs::msg::Object::_position_z_type arg)
  {
    msg_.position_z = std::move(arg);
    return Init_Object_position_z_std(msg_);
  }

private:
  ::radar_msgs::msg::Object msg_;
};

class Init_Object_position_y_std
{
public:
  explicit Init_Object_position_y_std(::radar_msgs::msg::Object & msg)
  : msg_(msg)
  {}
  Init_Object_position_z position_y_std(::radar_msgs::msg::Object::_position_y_std_type arg)
  {
    msg_.position_y_std = std::move(arg);
    return Init_Object_position_z(msg_);
  }

private:
  ::radar_msgs::msg::Object msg_;
};

class Init_Object_position_y
{
public:
  explicit Init_Object_position_y(::radar_msgs::msg::Object & msg)
  : msg_(msg)
  {}
  Init_Object_position_y_std position_y(::radar_msgs::msg::Object::_position_y_type arg)
  {
    msg_.position_y = std::move(arg);
    return Init_Object_position_y_std(msg_);
  }

private:
  ::radar_msgs::msg::Object msg_;
};

class Init_Object_position_x_std
{
public:
  explicit Init_Object_position_x_std(::radar_msgs::msg::Object & msg)
  : msg_(msg)
  {}
  Init_Object_position_y position_x_std(::radar_msgs::msg::Object::_position_x_std_type arg)
  {
    msg_.position_x_std = std::move(arg);
    return Init_Object_position_y(msg_);
  }

private:
  ::radar_msgs::msg::Object msg_;
};

class Init_Object_position_x
{
public:
  explicit Init_Object_position_x(::radar_msgs::msg::Object & msg)
  : msg_(msg)
  {}
  Init_Object_position_x_std position_x(::radar_msgs::msg::Object::_position_x_type arg)
  {
    msg_.position_x = std::move(arg);
    return Init_Object_position_x_std(msg_);
  }

private:
  ::radar_msgs::msg::Object msg_;
};

class Init_Object_position_reference
{
public:
  explicit Init_Object_position_reference(::radar_msgs::msg::Object & msg)
  : msg_(msg)
  {}
  Init_Object_position_x position_reference(::radar_msgs::msg::Object::_position_reference_type arg)
  {
    msg_.position_reference = std::move(arg);
    return Init_Object_position_x(msg_);
  }

private:
  ::radar_msgs::msg::Object msg_;
};

class Init_Object_object_status_movement
{
public:
  explicit Init_Object_object_status_movement(::radar_msgs::msg::Object & msg)
  : msg_(msg)
  {}
  Init_Object_position_reference object_status_movement(::radar_msgs::msg::Object::_object_status_movement_type arg)
  {
    msg_.object_status_movement = std::move(arg);
    return Init_Object_position_reference(msg_);
  }

private:
  ::radar_msgs::msg::Object msg_;
};

class Init_Object_object_status_measurement
{
public:
  explicit Init_Object_object_status_measurement(::radar_msgs::msg::Object & msg)
  : msg_(msg)
  {}
  Init_Object_object_status_movement object_status_measurement(::radar_msgs::msg::Object::_object_status_measurement_type arg)
  {
    msg_.object_status_measurement = std::move(arg);
    return Init_Object_object_status_movement(msg_);
  }

private:
  ::radar_msgs::msg::Object msg_;
};

class Init_Object_object_age
{
public:
  explicit Init_Object_object_age(::radar_msgs::msg::Object & msg)
  : msg_(msg)
  {}
  Init_Object_object_status_measurement object_age(::radar_msgs::msg::Object::_object_age_type arg)
  {
    msg_.object_age = std::move(arg);
    return Init_Object_object_status_measurement(msg_);
  }

private:
  ::radar_msgs::msg::Object msg_;
};

class Init_Object_object_id
{
public:
  Init_Object_object_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Object_object_age object_id(::radar_msgs::msg::Object::_object_id_type arg)
  {
    msg_.object_id = std::move(arg);
    return Init_Object_object_age(msg_);
  }

private:
  ::radar_msgs::msg::Object msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::radar_msgs::msg::Object>()
{
  return radar_msgs::msg::builder::Init_Object_object_id();
}

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__OBJECT__BUILDER_HPP_
