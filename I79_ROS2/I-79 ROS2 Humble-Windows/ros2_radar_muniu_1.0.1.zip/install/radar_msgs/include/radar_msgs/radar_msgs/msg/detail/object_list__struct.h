// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from radar_msgs:msg\ObjectList.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__OBJECT_LIST__STRUCT_H_
#define RADAR_MSGS__MSG__DETAIL__OBJECT_LIST__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'objectlist_objects'
#include "radar_msgs/msg/detail/object__struct.h"

/// Struct defined in msg/ObjectList in the package radar_msgs.
typedef struct radar_msgs__msg__ObjectList
{
  std_msgs__msg__Header header;
  uint64_t crc;
  uint32_t length;
  uint32_t sqc;
  uint32_t dataid;
  uint32_t timestamp_nanoseconds;
  uint32_t timestamp_seconds;
  uint8_t timestamp_syncstatus;
  uint32_t rsv1;
  uint8_t rsv2;
  uint32_t frame_count;
  uint8_t coordinate_system;
  float measurement_latency;
  uint8_t rsv3[32];
  uint8_t objectlist_numofobjects;
  radar_msgs__msg__Object__Sequence objectlist_objects;
} radar_msgs__msg__ObjectList;

// Struct for a sequence of radar_msgs__msg__ObjectList.
typedef struct radar_msgs__msg__ObjectList__Sequence
{
  radar_msgs__msg__ObjectList * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} radar_msgs__msg__ObjectList__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // RADAR_MSGS__MSG__DETAIL__OBJECT_LIST__STRUCT_H_
