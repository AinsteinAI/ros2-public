// generated from rosidl_generator_c/resource/idl.h.em
// with input from radar_msgs:msg\Detection.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETECTION_H_
#define RADAR_MSGS__MSG__DETECTION_H_

#include "radar_msgs/msg/detail/detection__struct.h"
#include "radar_msgs/msg/detail/detection__functions.h"
#include "radar_msgs/msg/detail/detection__type_support.h"

#endif  // RADAR_MSGS__MSG__DETECTION_H_
