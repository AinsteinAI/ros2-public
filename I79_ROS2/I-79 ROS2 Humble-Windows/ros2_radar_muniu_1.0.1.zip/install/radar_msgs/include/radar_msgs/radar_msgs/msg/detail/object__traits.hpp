// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from radar_msgs:msg\Object.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__OBJECT__TRAITS_HPP_
#define RADAR_MSGS__MSG__DETAIL__OBJECT__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "radar_msgs/msg/detail/object__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace radar_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const Object & msg,
  std::ostream & out)
{
  out << "{";
  // member: object_id
  {
    out << "object_id: ";
    rosidl_generator_traits::value_to_yaml(msg.object_id, out);
    out << ", ";
  }

  // member: object_age
  {
    out << "object_age: ";
    rosidl_generator_traits::value_to_yaml(msg.object_age, out);
    out << ", ";
  }

  // member: object_status_measurement
  {
    out << "object_status_measurement: ";
    rosidl_generator_traits::value_to_yaml(msg.object_status_measurement, out);
    out << ", ";
  }

  // member: object_status_movement
  {
    out << "object_status_movement: ";
    rosidl_generator_traits::value_to_yaml(msg.object_status_movement, out);
    out << ", ";
  }

  // member: position_reference
  {
    out << "position_reference: ";
    rosidl_generator_traits::value_to_yaml(msg.position_reference, out);
    out << ", ";
  }

  // member: position_x
  {
    out << "position_x: ";
    rosidl_generator_traits::value_to_yaml(msg.position_x, out);
    out << ", ";
  }

  // member: position_x_std
  {
    out << "position_x_std: ";
    rosidl_generator_traits::value_to_yaml(msg.position_x_std, out);
    out << ", ";
  }

  // member: position_y
  {
    out << "position_y: ";
    rosidl_generator_traits::value_to_yaml(msg.position_y, out);
    out << ", ";
  }

  // member: position_y_std
  {
    out << "position_y_std: ";
    rosidl_generator_traits::value_to_yaml(msg.position_y_std, out);
    out << ", ";
  }

  // member: position_z
  {
    out << "position_z: ";
    rosidl_generator_traits::value_to_yaml(msg.position_z, out);
    out << ", ";
  }

  // member: position_z_std
  {
    out << "position_z_std: ";
    rosidl_generator_traits::value_to_yaml(msg.position_z_std, out);
    out << ", ";
  }

  // member: position_orientation
  {
    out << "position_orientation: ";
    rosidl_generator_traits::value_to_yaml(msg.position_orientation, out);
    out << ", ";
  }

  // member: position_orientation_std
  {
    out << "position_orientation_std: ";
    rosidl_generator_traits::value_to_yaml(msg.position_orientation_std, out);
    out << ", ";
  }

  // member: dynamics_vel_x
  {
    out << "dynamics_vel_x: ";
    rosidl_generator_traits::value_to_yaml(msg.dynamics_vel_x, out);
    out << ", ";
  }

  // member: dynamics_vel_x_std
  {
    out << "dynamics_vel_x_std: ";
    rosidl_generator_traits::value_to_yaml(msg.dynamics_vel_x_std, out);
    out << ", ";
  }

  // member: dynamics_vel_y
  {
    out << "dynamics_vel_y: ";
    rosidl_generator_traits::value_to_yaml(msg.dynamics_vel_y, out);
    out << ", ";
  }

  // member: dynamics_vel_y_std
  {
    out << "dynamics_vel_y_std: ";
    rosidl_generator_traits::value_to_yaml(msg.dynamics_vel_y_std, out);
    out << ", ";
  }

  // member: dynamics_vel_z
  {
    out << "dynamics_vel_z: ";
    rosidl_generator_traits::value_to_yaml(msg.dynamics_vel_z, out);
    out << ", ";
  }

  // member: dynamics_vel_z_std
  {
    out << "dynamics_vel_z_std: ";
    rosidl_generator_traits::value_to_yaml(msg.dynamics_vel_z_std, out);
    out << ", ";
  }

  // member: dynamics_acce_x
  {
    out << "dynamics_acce_x: ";
    rosidl_generator_traits::value_to_yaml(msg.dynamics_acce_x, out);
    out << ", ";
  }

  // member: dynamics_acce_x_std
  {
    out << "dynamics_acce_x_std: ";
    rosidl_generator_traits::value_to_yaml(msg.dynamics_acce_x_std, out);
    out << ", ";
  }

  // member: dynamics_acce_y
  {
    out << "dynamics_acce_y: ";
    rosidl_generator_traits::value_to_yaml(msg.dynamics_acce_y, out);
    out << ", ";
  }

  // member: dynamics_acce_y_std
  {
    out << "dynamics_acce_y_std: ";
    rosidl_generator_traits::value_to_yaml(msg.dynamics_acce_y_std, out);
    out << ", ";
  }

  // member: dynamics_acce_z
  {
    out << "dynamics_acce_z: ";
    rosidl_generator_traits::value_to_yaml(msg.dynamics_acce_z, out);
    out << ", ";
  }

  // member: dynamics_acce_z_std
  {
    out << "dynamics_acce_z_std: ";
    rosidl_generator_traits::value_to_yaml(msg.dynamics_acce_z_std, out);
    out << ", ";
  }

  // member: dynamics_orientation_rate
  {
    out << "dynamics_orientation_rate: ";
    rosidl_generator_traits::value_to_yaml(msg.dynamics_orientation_rate, out);
    out << ", ";
  }

  // member: dynamics_orientation_rate_std
  {
    out << "dynamics_orientation_rate_std: ";
    rosidl_generator_traits::value_to_yaml(msg.dynamics_orientation_rate_std, out);
    out << ", ";
  }

  // member: existence_prob
  {
    out << "existence_prob: ";
    rosidl_generator_traits::value_to_yaml(msg.existence_prob, out);
    out << ", ";
  }

  // member: obstacle_prob
  {
    out << "obstacle_prob: ";
    rosidl_generator_traits::value_to_yaml(msg.obstacle_prob, out);
    out << ", ";
  }

  // member: classification
  {
    out << "classification: ";
    rosidl_generator_traits::value_to_yaml(msg.classification, out);
    out << ", ";
  }

  // member: classification_prob
  {
    out << "classification_prob: ";
    rosidl_generator_traits::value_to_yaml(msg.classification_prob, out);
    out << ", ";
  }

  // member: shape_length_mean
  {
    out << "shape_length_mean: ";
    rosidl_generator_traits::value_to_yaml(msg.shape_length_mean, out);
    out << ", ";
  }

  // member: shape_length_std
  {
    out << "shape_length_std: ";
    rosidl_generator_traits::value_to_yaml(msg.shape_length_std, out);
    out << ", ";
  }

  // member: shape_width_mean
  {
    out << "shape_width_mean: ";
    rosidl_generator_traits::value_to_yaml(msg.shape_width_mean, out);
    out << ", ";
  }

  // member: shape_width_std
  {
    out << "shape_width_std: ";
    rosidl_generator_traits::value_to_yaml(msg.shape_width_std, out);
    out << ", ";
  }

  // member: shape_height_mean
  {
    out << "shape_height_mean: ";
    rosidl_generator_traits::value_to_yaml(msg.shape_height_mean, out);
    out << ", ";
  }

  // member: shape_height_std
  {
    out << "shape_height_std: ";
    rosidl_generator_traits::value_to_yaml(msg.shape_height_std, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const Object & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: object_id
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "object_id: ";
    rosidl_generator_traits::value_to_yaml(msg.object_id, out);
    out << "\n";
  }

  // member: object_age
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "object_age: ";
    rosidl_generator_traits::value_to_yaml(msg.object_age, out);
    out << "\n";
  }

  // member: object_status_measurement
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "object_status_measurement: ";
    rosidl_generator_traits::value_to_yaml(msg.object_status_measurement, out);
    out << "\n";
  }

  // member: object_status_movement
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "object_status_movement: ";
    rosidl_generator_traits::value_to_yaml(msg.object_status_movement, out);
    out << "\n";
  }

  // member: position_reference
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "position_reference: ";
    rosidl_generator_traits::value_to_yaml(msg.position_reference, out);
    out << "\n";
  }

  // member: position_x
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "position_x: ";
    rosidl_generator_traits::value_to_yaml(msg.position_x, out);
    out << "\n";
  }

  // member: position_x_std
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "position_x_std: ";
    rosidl_generator_traits::value_to_yaml(msg.position_x_std, out);
    out << "\n";
  }

  // member: position_y
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "position_y: ";
    rosidl_generator_traits::value_to_yaml(msg.position_y, out);
    out << "\n";
  }

  // member: position_y_std
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "position_y_std: ";
    rosidl_generator_traits::value_to_yaml(msg.position_y_std, out);
    out << "\n";
  }

  // member: position_z
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "position_z: ";
    rosidl_generator_traits::value_to_yaml(msg.position_z, out);
    out << "\n";
  }

  // member: position_z_std
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "position_z_std: ";
    rosidl_generator_traits::value_to_yaml(msg.position_z_std, out);
    out << "\n";
  }

  // member: position_orientation
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "position_orientation: ";
    rosidl_generator_traits::value_to_yaml(msg.position_orientation, out);
    out << "\n";
  }

  // member: position_orientation_std
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "position_orientation_std: ";
    rosidl_generator_traits::value_to_yaml(msg.position_orientation_std, out);
    out << "\n";
  }

  // member: dynamics_vel_x
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "dynamics_vel_x: ";
    rosidl_generator_traits::value_to_yaml(msg.dynamics_vel_x, out);
    out << "\n";
  }

  // member: dynamics_vel_x_std
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "dynamics_vel_x_std: ";
    rosidl_generator_traits::value_to_yaml(msg.dynamics_vel_x_std, out);
    out << "\n";
  }

  // member: dynamics_vel_y
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "dynamics_vel_y: ";
    rosidl_generator_traits::value_to_yaml(msg.dynamics_vel_y, out);
    out << "\n";
  }

  // member: dynamics_vel_y_std
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "dynamics_vel_y_std: ";
    rosidl_generator_traits::value_to_yaml(msg.dynamics_vel_y_std, out);
    out << "\n";
  }

  // member: dynamics_vel_z
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "dynamics_vel_z: ";
    rosidl_generator_traits::value_to_yaml(msg.dynamics_vel_z, out);
    out << "\n";
  }

  // member: dynamics_vel_z_std
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "dynamics_vel_z_std: ";
    rosidl_generator_traits::value_to_yaml(msg.dynamics_vel_z_std, out);
    out << "\n";
  }

  // member: dynamics_acce_x
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "dynamics_acce_x: ";
    rosidl_generator_traits::value_to_yaml(msg.dynamics_acce_x, out);
    out << "\n";
  }

  // member: dynamics_acce_x_std
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "dynamics_acce_x_std: ";
    rosidl_generator_traits::value_to_yaml(msg.dynamics_acce_x_std, out);
    out << "\n";
  }

  // member: dynamics_acce_y
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "dynamics_acce_y: ";
    rosidl_generator_traits::value_to_yaml(msg.dynamics_acce_y, out);
    out << "\n";
  }

  // member: dynamics_acce_y_std
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "dynamics_acce_y_std: ";
    rosidl_generator_traits::value_to_yaml(msg.dynamics_acce_y_std, out);
    out << "\n";
  }

  // member: dynamics_acce_z
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "dynamics_acce_z: ";
    rosidl_generator_traits::value_to_yaml(msg.dynamics_acce_z, out);
    out << "\n";
  }

  // member: dynamics_acce_z_std
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "dynamics_acce_z_std: ";
    rosidl_generator_traits::value_to_yaml(msg.dynamics_acce_z_std, out);
    out << "\n";
  }

  // member: dynamics_orientation_rate
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "dynamics_orientation_rate: ";
    rosidl_generator_traits::value_to_yaml(msg.dynamics_orientation_rate, out);
    out << "\n";
  }

  // member: dynamics_orientation_rate_std
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "dynamics_orientation_rate_std: ";
    rosidl_generator_traits::value_to_yaml(msg.dynamics_orientation_rate_std, out);
    out << "\n";
  }

  // member: existence_prob
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "existence_prob: ";
    rosidl_generator_traits::value_to_yaml(msg.existence_prob, out);
    out << "\n";
  }

  // member: obstacle_prob
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "obstacle_prob: ";
    rosidl_generator_traits::value_to_yaml(msg.obstacle_prob, out);
    out << "\n";
  }

  // member: classification
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "classification: ";
    rosidl_generator_traits::value_to_yaml(msg.classification, out);
    out << "\n";
  }

  // member: classification_prob
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "classification_prob: ";
    rosidl_generator_traits::value_to_yaml(msg.classification_prob, out);
    out << "\n";
  }

  // member: shape_length_mean
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "shape_length_mean: ";
    rosidl_generator_traits::value_to_yaml(msg.shape_length_mean, out);
    out << "\n";
  }

  // member: shape_length_std
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "shape_length_std: ";
    rosidl_generator_traits::value_to_yaml(msg.shape_length_std, out);
    out << "\n";
  }

  // member: shape_width_mean
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "shape_width_mean: ";
    rosidl_generator_traits::value_to_yaml(msg.shape_width_mean, out);
    out << "\n";
  }

  // member: shape_width_std
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "shape_width_std: ";
    rosidl_generator_traits::value_to_yaml(msg.shape_width_std, out);
    out << "\n";
  }

  // member: shape_height_mean
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "shape_height_mean: ";
    rosidl_generator_traits::value_to_yaml(msg.shape_height_mean, out);
    out << "\n";
  }

  // member: shape_height_std
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "shape_height_std: ";
    rosidl_generator_traits::value_to_yaml(msg.shape_height_std, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const Object & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace radar_msgs

namespace rosidl_generator_traits
{

[[deprecated("use radar_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const radar_msgs::msg::Object & msg,
  std::ostream & out, size_t indentation = 0)
{
  radar_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use radar_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const radar_msgs::msg::Object & msg)
{
  return radar_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<radar_msgs::msg::Object>()
{
  return "radar_msgs::msg::Object";
}

template<>
inline const char * name<radar_msgs::msg::Object>()
{
  return "radar_msgs/msg/Object";
}

template<>
struct has_fixed_size<radar_msgs::msg::Object>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<radar_msgs::msg::Object>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<radar_msgs::msg::Object>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // RADAR_MSGS__MSG__DETAIL__OBJECT__TRAITS_HPP_
