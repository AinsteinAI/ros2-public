// generated from rosidl_generator_c/resource/idl.h.em
// with input from radar_msgs:msg\Object.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__OBJECT_H_
#define RADAR_MSGS__MSG__OBJECT_H_

#include "radar_msgs/msg/detail/object__struct.h"
#include "radar_msgs/msg/detail/object__functions.h"
#include "radar_msgs/msg/detail/object__type_support.h"

#endif  // RADAR_MSGS__MSG__OBJECT_H_
