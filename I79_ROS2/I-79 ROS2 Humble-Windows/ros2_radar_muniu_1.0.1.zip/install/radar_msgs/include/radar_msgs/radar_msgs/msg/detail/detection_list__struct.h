// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from radar_msgs:msg\DetectionList.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__DETECTION_LIST__STRUCT_H_
#define RADAR_MSGS__MSG__DETAIL__DETECTION_LIST__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'list_detections'
#include "radar_msgs/msg/detail/detection__struct.h"

/// Struct defined in msg/DetectionList in the package radar_msgs.
typedef struct radar_msgs__msg__DetectionList
{
  std_msgs__msg__Header header;
  uint64_t crc;
  uint32_t length;
  uint32_t sqc;
  uint32_t data_id;
  uint16_t version_code;
  uint32_t frame_count;
  uint8_t frame_period_time;
  uint32_t timestamp_nanoseconds;
  uint32_t timestamp_seconds;
  uint8_t timestamp_sync_status;
  uint32_t rsv1;
  uint8_t rsv2;
  uint8_t coordinate_system;
  float measurement_latency;
  uint16_t origin_invalid_flags;
  float origin_xpos;
  float origin_xstd;
  float origin_ypos;
  float origin_ystd;
  float origin_zpos;
  float origin_zstd;
  float origin_roll;
  float origin_rollstd;
  float origin_pitch;
  float origin_pitchstd;
  float origin_yaw;
  float origin_yawstd;
  uint8_t list_invalid_flags;
  float aln_azimuth_correction;
  float aln_elevation_correction;
  uint8_t rsv_weather;
  uint8_t rsv_road_status;
  uint8_t rsv_aucc_frame_count;
  uint8_t rsv_profile_id;
  uint32_t rsv_adc_anti_num;
  uint32_t rsv_adc_real_higer_thod_cnt;
  uint32_t rsv_adc_imag_higer_thod_cnt;
  uint8_t u_rsv_bfm_coeff_error_flag;
  uint32_t rsv_ci_noise_median;
  uint32_t rsv_nci_noise_median;
  uint8_t rsv3[16];
  uint8_t list_len_of_detections;
  uint32_t list_num_of_detections;
  radar_msgs__msg__Detection__Sequence list_detections;
} radar_msgs__msg__DetectionList;

// Struct for a sequence of radar_msgs__msg__DetectionList.
typedef struct radar_msgs__msg__DetectionList__Sequence
{
  radar_msgs__msg__DetectionList * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} radar_msgs__msg__DetectionList__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // RADAR_MSGS__MSG__DETAIL__DETECTION_LIST__STRUCT_H_
