// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__OBJECT_HPP_
#define RADAR_MSGS__MSG__OBJECT_HPP_

#include "radar_msgs/msg/detail/object__struct.hpp"
#include "radar_msgs/msg/detail/object__builder.hpp"
#include "radar_msgs/msg/detail/object__traits.hpp"

#endif  // RADAR_MSGS__MSG__OBJECT_HPP_
