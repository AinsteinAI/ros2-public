// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from radar_msgs:msg\ObjectList.idl
// generated code does not contain a copyright notice
#include "radar_msgs/msg/detail/object_list__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"
// Member `objectlist_objects`
#include "radar_msgs/msg/detail/object__functions.h"

bool
radar_msgs__msg__ObjectList__init(radar_msgs__msg__ObjectList * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    radar_msgs__msg__ObjectList__fini(msg);
    return false;
  }
  // crc
  // length
  // sqc
  // dataid
  // timestamp_nanoseconds
  // timestamp_seconds
  // timestamp_syncstatus
  // rsv1
  // rsv2
  // frame_count
  // coordinate_system
  // measurement_latency
  // rsv3
  // objectlist_numofobjects
  // objectlist_objects
  if (!radar_msgs__msg__Object__Sequence__init(&msg->objectlist_objects, 0)) {
    radar_msgs__msg__ObjectList__fini(msg);
    return false;
  }
  return true;
}

void
radar_msgs__msg__ObjectList__fini(radar_msgs__msg__ObjectList * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // crc
  // length
  // sqc
  // dataid
  // timestamp_nanoseconds
  // timestamp_seconds
  // timestamp_syncstatus
  // rsv1
  // rsv2
  // frame_count
  // coordinate_system
  // measurement_latency
  // rsv3
  // objectlist_numofobjects
  // objectlist_objects
  radar_msgs__msg__Object__Sequence__fini(&msg->objectlist_objects);
}

bool
radar_msgs__msg__ObjectList__are_equal(const radar_msgs__msg__ObjectList * lhs, const radar_msgs__msg__ObjectList * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // crc
  if (lhs->crc != rhs->crc) {
    return false;
  }
  // length
  if (lhs->length != rhs->length) {
    return false;
  }
  // sqc
  if (lhs->sqc != rhs->sqc) {
    return false;
  }
  // dataid
  if (lhs->dataid != rhs->dataid) {
    return false;
  }
  // timestamp_nanoseconds
  if (lhs->timestamp_nanoseconds != rhs->timestamp_nanoseconds) {
    return false;
  }
  // timestamp_seconds
  if (lhs->timestamp_seconds != rhs->timestamp_seconds) {
    return false;
  }
  // timestamp_syncstatus
  if (lhs->timestamp_syncstatus != rhs->timestamp_syncstatus) {
    return false;
  }
  // rsv1
  if (lhs->rsv1 != rhs->rsv1) {
    return false;
  }
  // rsv2
  if (lhs->rsv2 != rhs->rsv2) {
    return false;
  }
  // frame_count
  if (lhs->frame_count != rhs->frame_count) {
    return false;
  }
  // coordinate_system
  if (lhs->coordinate_system != rhs->coordinate_system) {
    return false;
  }
  // measurement_latency
  if (lhs->measurement_latency != rhs->measurement_latency) {
    return false;
  }
  // rsv3
  for (size_t i = 0; i < 32; ++i) {
    if (lhs->rsv3[i] != rhs->rsv3[i]) {
      return false;
    }
  }
  // objectlist_numofobjects
  if (lhs->objectlist_numofobjects != rhs->objectlist_numofobjects) {
    return false;
  }
  // objectlist_objects
  if (!radar_msgs__msg__Object__Sequence__are_equal(
      &(lhs->objectlist_objects), &(rhs->objectlist_objects)))
  {
    return false;
  }
  return true;
}

bool
radar_msgs__msg__ObjectList__copy(
  const radar_msgs__msg__ObjectList * input,
  radar_msgs__msg__ObjectList * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // crc
  output->crc = input->crc;
  // length
  output->length = input->length;
  // sqc
  output->sqc = input->sqc;
  // dataid
  output->dataid = input->dataid;
  // timestamp_nanoseconds
  output->timestamp_nanoseconds = input->timestamp_nanoseconds;
  // timestamp_seconds
  output->timestamp_seconds = input->timestamp_seconds;
  // timestamp_syncstatus
  output->timestamp_syncstatus = input->timestamp_syncstatus;
  // rsv1
  output->rsv1 = input->rsv1;
  // rsv2
  output->rsv2 = input->rsv2;
  // frame_count
  output->frame_count = input->frame_count;
  // coordinate_system
  output->coordinate_system = input->coordinate_system;
  // measurement_latency
  output->measurement_latency = input->measurement_latency;
  // rsv3
  for (size_t i = 0; i < 32; ++i) {
    output->rsv3[i] = input->rsv3[i];
  }
  // objectlist_numofobjects
  output->objectlist_numofobjects = input->objectlist_numofobjects;
  // objectlist_objects
  if (!radar_msgs__msg__Object__Sequence__copy(
      &(input->objectlist_objects), &(output->objectlist_objects)))
  {
    return false;
  }
  return true;
}

radar_msgs__msg__ObjectList *
radar_msgs__msg__ObjectList__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__ObjectList * msg = (radar_msgs__msg__ObjectList *)allocator.allocate(sizeof(radar_msgs__msg__ObjectList), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(radar_msgs__msg__ObjectList));
  bool success = radar_msgs__msg__ObjectList__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
radar_msgs__msg__ObjectList__destroy(radar_msgs__msg__ObjectList * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    radar_msgs__msg__ObjectList__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
radar_msgs__msg__ObjectList__Sequence__init(radar_msgs__msg__ObjectList__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__ObjectList * data = NULL;

  if (size) {
    data = (radar_msgs__msg__ObjectList *)allocator.zero_allocate(size, sizeof(radar_msgs__msg__ObjectList), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = radar_msgs__msg__ObjectList__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        radar_msgs__msg__ObjectList__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
radar_msgs__msg__ObjectList__Sequence__fini(radar_msgs__msg__ObjectList__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      radar_msgs__msg__ObjectList__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

radar_msgs__msg__ObjectList__Sequence *
radar_msgs__msg__ObjectList__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__ObjectList__Sequence * array = (radar_msgs__msg__ObjectList__Sequence *)allocator.allocate(sizeof(radar_msgs__msg__ObjectList__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = radar_msgs__msg__ObjectList__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
radar_msgs__msg__ObjectList__Sequence__destroy(radar_msgs__msg__ObjectList__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    radar_msgs__msg__ObjectList__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
radar_msgs__msg__ObjectList__Sequence__are_equal(const radar_msgs__msg__ObjectList__Sequence * lhs, const radar_msgs__msg__ObjectList__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!radar_msgs__msg__ObjectList__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
radar_msgs__msg__ObjectList__Sequence__copy(
  const radar_msgs__msg__ObjectList__Sequence * input,
  radar_msgs__msg__ObjectList__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(radar_msgs__msg__ObjectList);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    radar_msgs__msg__ObjectList * data =
      (radar_msgs__msg__ObjectList *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!radar_msgs__msg__ObjectList__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          radar_msgs__msg__ObjectList__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!radar_msgs__msg__ObjectList__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
