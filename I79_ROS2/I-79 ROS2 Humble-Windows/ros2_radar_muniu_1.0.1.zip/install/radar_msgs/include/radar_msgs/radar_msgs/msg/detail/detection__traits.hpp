// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from radar_msgs:msg\Detection.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__DETECTION__TRAITS_HPP_
#define RADAR_MSGS__MSG__DETAIL__DETECTION__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "radar_msgs/msg/detail/detection__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace radar_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const Detection & msg,
  std::ostream & out)
{
  out << "{";
  // member: measurement_id
  {
    out << "measurement_id: ";
    rosidl_generator_traits::value_to_yaml(msg.measurement_id, out);
    out << ", ";
  }

  // member: azimuth_angle
  {
    out << "azimuth_angle: ";
    rosidl_generator_traits::value_to_yaml(msg.azimuth_angle, out);
    out << ", ";
  }

  // member: azimuth_angle_std
  {
    out << "azimuth_angle_std: ";
    rosidl_generator_traits::value_to_yaml(msg.azimuth_angle_std, out);
    out << ", ";
  }

  // member: invalid_flags
  {
    out << "invalid_flags: ";
    rosidl_generator_traits::value_to_yaml(msg.invalid_flags, out);
    out << ", ";
  }

  // member: elevation_angle
  {
    out << "elevation_angle: ";
    rosidl_generator_traits::value_to_yaml(msg.elevation_angle, out);
    out << ", ";
  }

  // member: elevation_angle_std
  {
    out << "elevation_angle_std: ";
    rosidl_generator_traits::value_to_yaml(msg.elevation_angle_std, out);
    out << ", ";
  }

  // member: range
  {
    out << "range: ";
    rosidl_generator_traits::value_to_yaml(msg.range, out);
    out << ", ";
  }

  // member: range_std
  {
    out << "range_std: ";
    rosidl_generator_traits::value_to_yaml(msg.range_std, out);
    out << ", ";
  }

  // member: range_rate
  {
    out << "range_rate: ";
    rosidl_generator_traits::value_to_yaml(msg.range_rate, out);
    out << ", ";
  }

  // member: range_rate_std
  {
    out << "range_rate_std: ";
    rosidl_generator_traits::value_to_yaml(msg.range_rate_std, out);
    out << ", ";
  }

  // member: rcs
  {
    out << "rcs: ";
    rosidl_generator_traits::value_to_yaml(msg.rcs, out);
    out << ", ";
  }

  // member: snr
  {
    out << "snr: ";
    rosidl_generator_traits::value_to_yaml(msg.snr, out);
    out << ", ";
  }

  // member: positive_predictive_value
  {
    out << "positive_predictive_value: ";
    rosidl_generator_traits::value_to_yaml(msg.positive_predictive_value, out);
    out << ", ";
  }

  // member: classification
  {
    out << "classification: ";
    rosidl_generator_traits::value_to_yaml(msg.classification, out);
    out << ", ";
  }

  // member: ambiguity_flag
  {
    out << "ambiguity_flag: ";
    rosidl_generator_traits::value_to_yaml(msg.ambiguity_flag, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const Detection & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: measurement_id
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "measurement_id: ";
    rosidl_generator_traits::value_to_yaml(msg.measurement_id, out);
    out << "\n";
  }

  // member: azimuth_angle
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "azimuth_angle: ";
    rosidl_generator_traits::value_to_yaml(msg.azimuth_angle, out);
    out << "\n";
  }

  // member: azimuth_angle_std
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "azimuth_angle_std: ";
    rosidl_generator_traits::value_to_yaml(msg.azimuth_angle_std, out);
    out << "\n";
  }

  // member: invalid_flags
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "invalid_flags: ";
    rosidl_generator_traits::value_to_yaml(msg.invalid_flags, out);
    out << "\n";
  }

  // member: elevation_angle
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "elevation_angle: ";
    rosidl_generator_traits::value_to_yaml(msg.elevation_angle, out);
    out << "\n";
  }

  // member: elevation_angle_std
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "elevation_angle_std: ";
    rosidl_generator_traits::value_to_yaml(msg.elevation_angle_std, out);
    out << "\n";
  }

  // member: range
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "range: ";
    rosidl_generator_traits::value_to_yaml(msg.range, out);
    out << "\n";
  }

  // member: range_std
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "range_std: ";
    rosidl_generator_traits::value_to_yaml(msg.range_std, out);
    out << "\n";
  }

  // member: range_rate
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "range_rate: ";
    rosidl_generator_traits::value_to_yaml(msg.range_rate, out);
    out << "\n";
  }

  // member: range_rate_std
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "range_rate_std: ";
    rosidl_generator_traits::value_to_yaml(msg.range_rate_std, out);
    out << "\n";
  }

  // member: rcs
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "rcs: ";
    rosidl_generator_traits::value_to_yaml(msg.rcs, out);
    out << "\n";
  }

  // member: snr
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "snr: ";
    rosidl_generator_traits::value_to_yaml(msg.snr, out);
    out << "\n";
  }

  // member: positive_predictive_value
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "positive_predictive_value: ";
    rosidl_generator_traits::value_to_yaml(msg.positive_predictive_value, out);
    out << "\n";
  }

  // member: classification
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "classification: ";
    rosidl_generator_traits::value_to_yaml(msg.classification, out);
    out << "\n";
  }

  // member: ambiguity_flag
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "ambiguity_flag: ";
    rosidl_generator_traits::value_to_yaml(msg.ambiguity_flag, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const Detection & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace radar_msgs

namespace rosidl_generator_traits
{

[[deprecated("use radar_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const radar_msgs::msg::Detection & msg,
  std::ostream & out, size_t indentation = 0)
{
  radar_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use radar_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const radar_msgs::msg::Detection & msg)
{
  return radar_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<radar_msgs::msg::Detection>()
{
  return "radar_msgs::msg::Detection";
}

template<>
inline const char * name<radar_msgs::msg::Detection>()
{
  return "radar_msgs/msg/Detection";
}

template<>
struct has_fixed_size<radar_msgs::msg::Detection>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<radar_msgs::msg::Detection>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<radar_msgs::msg::Detection>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // RADAR_MSGS__MSG__DETAIL__DETECTION__TRAITS_HPP_
