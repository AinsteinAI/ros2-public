// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from radar_msgs:msg\Object.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__OBJECT__STRUCT_HPP_
#define RADAR_MSGS__MSG__DETAIL__OBJECT__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__radar_msgs__msg__Object __attribute__((deprecated))
#else
# define DEPRECATED__radar_msgs__msg__Object __declspec(deprecated)
#endif

namespace radar_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct Object_
{
  using Type = Object_<ContainerAllocator>;

  explicit Object_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->object_id = 0ul;
      this->object_age = 0;
      this->object_status_measurement = 0;
      this->object_status_movement = 0;
      this->position_reference = 0;
      this->position_x = 0.0f;
      this->position_x_std = 0.0f;
      this->position_y = 0.0f;
      this->position_y_std = 0.0f;
      this->position_z = 0.0f;
      this->position_z_std = 0.0f;
      this->position_orientation = 0.0f;
      this->position_orientation_std = 0.0f;
      this->dynamics_vel_x = 0.0f;
      this->dynamics_vel_x_std = 0.0f;
      this->dynamics_vel_y = 0.0f;
      this->dynamics_vel_y_std = 0.0f;
      this->dynamics_vel_z = 0.0f;
      this->dynamics_vel_z_std = 0.0f;
      this->dynamics_acce_x = 0.0f;
      this->dynamics_acce_x_std = 0.0f;
      this->dynamics_acce_y = 0.0f;
      this->dynamics_acce_y_std = 0.0f;
      this->dynamics_acce_z = 0.0f;
      this->dynamics_acce_z_std = 0.0f;
      this->dynamics_orientation_rate = 0.0f;
      this->dynamics_orientation_rate_std = 0.0f;
      this->existence_prob = 0.0f;
      this->obstacle_prob = 0.0f;
      this->classification = 0;
      this->classification_prob = 0;
      this->shape_length_mean = 0.0f;
      this->shape_length_std = 0.0f;
      this->shape_width_mean = 0.0f;
      this->shape_width_std = 0.0f;
      this->shape_height_mean = 0.0f;
      this->shape_height_std = 0.0f;
    }
  }

  explicit Object_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->object_id = 0ul;
      this->object_age = 0;
      this->object_status_measurement = 0;
      this->object_status_movement = 0;
      this->position_reference = 0;
      this->position_x = 0.0f;
      this->position_x_std = 0.0f;
      this->position_y = 0.0f;
      this->position_y_std = 0.0f;
      this->position_z = 0.0f;
      this->position_z_std = 0.0f;
      this->position_orientation = 0.0f;
      this->position_orientation_std = 0.0f;
      this->dynamics_vel_x = 0.0f;
      this->dynamics_vel_x_std = 0.0f;
      this->dynamics_vel_y = 0.0f;
      this->dynamics_vel_y_std = 0.0f;
      this->dynamics_vel_z = 0.0f;
      this->dynamics_vel_z_std = 0.0f;
      this->dynamics_acce_x = 0.0f;
      this->dynamics_acce_x_std = 0.0f;
      this->dynamics_acce_y = 0.0f;
      this->dynamics_acce_y_std = 0.0f;
      this->dynamics_acce_z = 0.0f;
      this->dynamics_acce_z_std = 0.0f;
      this->dynamics_orientation_rate = 0.0f;
      this->dynamics_orientation_rate_std = 0.0f;
      this->existence_prob = 0.0f;
      this->obstacle_prob = 0.0f;
      this->classification = 0;
      this->classification_prob = 0;
      this->shape_length_mean = 0.0f;
      this->shape_length_std = 0.0f;
      this->shape_width_mean = 0.0f;
      this->shape_width_std = 0.0f;
      this->shape_height_mean = 0.0f;
      this->shape_height_std = 0.0f;
    }
  }

  // field types and members
  using _object_id_type =
    uint32_t;
  _object_id_type object_id;
  using _object_age_type =
    uint16_t;
  _object_age_type object_age;
  using _object_status_measurement_type =
    uint8_t;
  _object_status_measurement_type object_status_measurement;
  using _object_status_movement_type =
    uint8_t;
  _object_status_movement_type object_status_movement;
  using _position_reference_type =
    uint8_t;
  _position_reference_type position_reference;
  using _position_x_type =
    float;
  _position_x_type position_x;
  using _position_x_std_type =
    float;
  _position_x_std_type position_x_std;
  using _position_y_type =
    float;
  _position_y_type position_y;
  using _position_y_std_type =
    float;
  _position_y_std_type position_y_std;
  using _position_z_type =
    float;
  _position_z_type position_z;
  using _position_z_std_type =
    float;
  _position_z_std_type position_z_std;
  using _position_orientation_type =
    float;
  _position_orientation_type position_orientation;
  using _position_orientation_std_type =
    float;
  _position_orientation_std_type position_orientation_std;
  using _dynamics_vel_x_type =
    float;
  _dynamics_vel_x_type dynamics_vel_x;
  using _dynamics_vel_x_std_type =
    float;
  _dynamics_vel_x_std_type dynamics_vel_x_std;
  using _dynamics_vel_y_type =
    float;
  _dynamics_vel_y_type dynamics_vel_y;
  using _dynamics_vel_y_std_type =
    float;
  _dynamics_vel_y_std_type dynamics_vel_y_std;
  using _dynamics_vel_z_type =
    float;
  _dynamics_vel_z_type dynamics_vel_z;
  using _dynamics_vel_z_std_type =
    float;
  _dynamics_vel_z_std_type dynamics_vel_z_std;
  using _dynamics_acce_x_type =
    float;
  _dynamics_acce_x_type dynamics_acce_x;
  using _dynamics_acce_x_std_type =
    float;
  _dynamics_acce_x_std_type dynamics_acce_x_std;
  using _dynamics_acce_y_type =
    float;
  _dynamics_acce_y_type dynamics_acce_y;
  using _dynamics_acce_y_std_type =
    float;
  _dynamics_acce_y_std_type dynamics_acce_y_std;
  using _dynamics_acce_z_type =
    float;
  _dynamics_acce_z_type dynamics_acce_z;
  using _dynamics_acce_z_std_type =
    float;
  _dynamics_acce_z_std_type dynamics_acce_z_std;
  using _dynamics_orientation_rate_type =
    float;
  _dynamics_orientation_rate_type dynamics_orientation_rate;
  using _dynamics_orientation_rate_std_type =
    float;
  _dynamics_orientation_rate_std_type dynamics_orientation_rate_std;
  using _existence_prob_type =
    float;
  _existence_prob_type existence_prob;
  using _obstacle_prob_type =
    float;
  _obstacle_prob_type obstacle_prob;
  using _classification_type =
    uint8_t;
  _classification_type classification;
  using _classification_prob_type =
    uint8_t;
  _classification_prob_type classification_prob;
  using _shape_length_mean_type =
    float;
  _shape_length_mean_type shape_length_mean;
  using _shape_length_std_type =
    float;
  _shape_length_std_type shape_length_std;
  using _shape_width_mean_type =
    float;
  _shape_width_mean_type shape_width_mean;
  using _shape_width_std_type =
    float;
  _shape_width_std_type shape_width_std;
  using _shape_height_mean_type =
    float;
  _shape_height_mean_type shape_height_mean;
  using _shape_height_std_type =
    float;
  _shape_height_std_type shape_height_std;

  // setters for named parameter idiom
  Type & set__object_id(
    const uint32_t & _arg)
  {
    this->object_id = _arg;
    return *this;
  }
  Type & set__object_age(
    const uint16_t & _arg)
  {
    this->object_age = _arg;
    return *this;
  }
  Type & set__object_status_measurement(
    const uint8_t & _arg)
  {
    this->object_status_measurement = _arg;
    return *this;
  }
  Type & set__object_status_movement(
    const uint8_t & _arg)
  {
    this->object_status_movement = _arg;
    return *this;
  }
  Type & set__position_reference(
    const uint8_t & _arg)
  {
    this->position_reference = _arg;
    return *this;
  }
  Type & set__position_x(
    const float & _arg)
  {
    this->position_x = _arg;
    return *this;
  }
  Type & set__position_x_std(
    const float & _arg)
  {
    this->position_x_std = _arg;
    return *this;
  }
  Type & set__position_y(
    const float & _arg)
  {
    this->position_y = _arg;
    return *this;
  }
  Type & set__position_y_std(
    const float & _arg)
  {
    this->position_y_std = _arg;
    return *this;
  }
  Type & set__position_z(
    const float & _arg)
  {
    this->position_z = _arg;
    return *this;
  }
  Type & set__position_z_std(
    const float & _arg)
  {
    this->position_z_std = _arg;
    return *this;
  }
  Type & set__position_orientation(
    const float & _arg)
  {
    this->position_orientation = _arg;
    return *this;
  }
  Type & set__position_orientation_std(
    const float & _arg)
  {
    this->position_orientation_std = _arg;
    return *this;
  }
  Type & set__dynamics_vel_x(
    const float & _arg)
  {
    this->dynamics_vel_x = _arg;
    return *this;
  }
  Type & set__dynamics_vel_x_std(
    const float & _arg)
  {
    this->dynamics_vel_x_std = _arg;
    return *this;
  }
  Type & set__dynamics_vel_y(
    const float & _arg)
  {
    this->dynamics_vel_y = _arg;
    return *this;
  }
  Type & set__dynamics_vel_y_std(
    const float & _arg)
  {
    this->dynamics_vel_y_std = _arg;
    return *this;
  }
  Type & set__dynamics_vel_z(
    const float & _arg)
  {
    this->dynamics_vel_z = _arg;
    return *this;
  }
  Type & set__dynamics_vel_z_std(
    const float & _arg)
  {
    this->dynamics_vel_z_std = _arg;
    return *this;
  }
  Type & set__dynamics_acce_x(
    const float & _arg)
  {
    this->dynamics_acce_x = _arg;
    return *this;
  }
  Type & set__dynamics_acce_x_std(
    const float & _arg)
  {
    this->dynamics_acce_x_std = _arg;
    return *this;
  }
  Type & set__dynamics_acce_y(
    const float & _arg)
  {
    this->dynamics_acce_y = _arg;
    return *this;
  }
  Type & set__dynamics_acce_y_std(
    const float & _arg)
  {
    this->dynamics_acce_y_std = _arg;
    return *this;
  }
  Type & set__dynamics_acce_z(
    const float & _arg)
  {
    this->dynamics_acce_z = _arg;
    return *this;
  }
  Type & set__dynamics_acce_z_std(
    const float & _arg)
  {
    this->dynamics_acce_z_std = _arg;
    return *this;
  }
  Type & set__dynamics_orientation_rate(
    const float & _arg)
  {
    this->dynamics_orientation_rate = _arg;
    return *this;
  }
  Type & set__dynamics_orientation_rate_std(
    const float & _arg)
  {
    this->dynamics_orientation_rate_std = _arg;
    return *this;
  }
  Type & set__existence_prob(
    const float & _arg)
  {
    this->existence_prob = _arg;
    return *this;
  }
  Type & set__obstacle_prob(
    const float & _arg)
  {
    this->obstacle_prob = _arg;
    return *this;
  }
  Type & set__classification(
    const uint8_t & _arg)
  {
    this->classification = _arg;
    return *this;
  }
  Type & set__classification_prob(
    const uint8_t & _arg)
  {
    this->classification_prob = _arg;
    return *this;
  }
  Type & set__shape_length_mean(
    const float & _arg)
  {
    this->shape_length_mean = _arg;
    return *this;
  }
  Type & set__shape_length_std(
    const float & _arg)
  {
    this->shape_length_std = _arg;
    return *this;
  }
  Type & set__shape_width_mean(
    const float & _arg)
  {
    this->shape_width_mean = _arg;
    return *this;
  }
  Type & set__shape_width_std(
    const float & _arg)
  {
    this->shape_width_std = _arg;
    return *this;
  }
  Type & set__shape_height_mean(
    const float & _arg)
  {
    this->shape_height_mean = _arg;
    return *this;
  }
  Type & set__shape_height_std(
    const float & _arg)
  {
    this->shape_height_std = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    radar_msgs::msg::Object_<ContainerAllocator> *;
  using ConstRawPtr =
    const radar_msgs::msg::Object_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<radar_msgs::msg::Object_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<radar_msgs::msg::Object_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      radar_msgs::msg::Object_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<radar_msgs::msg::Object_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      radar_msgs::msg::Object_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<radar_msgs::msg::Object_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<radar_msgs::msg::Object_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<radar_msgs::msg::Object_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__radar_msgs__msg__Object
    std::shared_ptr<radar_msgs::msg::Object_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__radar_msgs__msg__Object
    std::shared_ptr<radar_msgs::msg::Object_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const Object_ & other) const
  {
    if (this->object_id != other.object_id) {
      return false;
    }
    if (this->object_age != other.object_age) {
      return false;
    }
    if (this->object_status_measurement != other.object_status_measurement) {
      return false;
    }
    if (this->object_status_movement != other.object_status_movement) {
      return false;
    }
    if (this->position_reference != other.position_reference) {
      return false;
    }
    if (this->position_x != other.position_x) {
      return false;
    }
    if (this->position_x_std != other.position_x_std) {
      return false;
    }
    if (this->position_y != other.position_y) {
      return false;
    }
    if (this->position_y_std != other.position_y_std) {
      return false;
    }
    if (this->position_z != other.position_z) {
      return false;
    }
    if (this->position_z_std != other.position_z_std) {
      return false;
    }
    if (this->position_orientation != other.position_orientation) {
      return false;
    }
    if (this->position_orientation_std != other.position_orientation_std) {
      return false;
    }
    if (this->dynamics_vel_x != other.dynamics_vel_x) {
      return false;
    }
    if (this->dynamics_vel_x_std != other.dynamics_vel_x_std) {
      return false;
    }
    if (this->dynamics_vel_y != other.dynamics_vel_y) {
      return false;
    }
    if (this->dynamics_vel_y_std != other.dynamics_vel_y_std) {
      return false;
    }
    if (this->dynamics_vel_z != other.dynamics_vel_z) {
      return false;
    }
    if (this->dynamics_vel_z_std != other.dynamics_vel_z_std) {
      return false;
    }
    if (this->dynamics_acce_x != other.dynamics_acce_x) {
      return false;
    }
    if (this->dynamics_acce_x_std != other.dynamics_acce_x_std) {
      return false;
    }
    if (this->dynamics_acce_y != other.dynamics_acce_y) {
      return false;
    }
    if (this->dynamics_acce_y_std != other.dynamics_acce_y_std) {
      return false;
    }
    if (this->dynamics_acce_z != other.dynamics_acce_z) {
      return false;
    }
    if (this->dynamics_acce_z_std != other.dynamics_acce_z_std) {
      return false;
    }
    if (this->dynamics_orientation_rate != other.dynamics_orientation_rate) {
      return false;
    }
    if (this->dynamics_orientation_rate_std != other.dynamics_orientation_rate_std) {
      return false;
    }
    if (this->existence_prob != other.existence_prob) {
      return false;
    }
    if (this->obstacle_prob != other.obstacle_prob) {
      return false;
    }
    if (this->classification != other.classification) {
      return false;
    }
    if (this->classification_prob != other.classification_prob) {
      return false;
    }
    if (this->shape_length_mean != other.shape_length_mean) {
      return false;
    }
    if (this->shape_length_std != other.shape_length_std) {
      return false;
    }
    if (this->shape_width_mean != other.shape_width_mean) {
      return false;
    }
    if (this->shape_width_std != other.shape_width_std) {
      return false;
    }
    if (this->shape_height_mean != other.shape_height_mean) {
      return false;
    }
    if (this->shape_height_std != other.shape_height_std) {
      return false;
    }
    return true;
  }
  bool operator!=(const Object_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct Object_

// alias to use template instance with default allocator
using Object =
  radar_msgs::msg::Object_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__OBJECT__STRUCT_HPP_
