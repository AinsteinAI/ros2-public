// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from radar_msgs:msg\DetectionList.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__DETECTION_LIST__TRAITS_HPP_
#define RADAR_MSGS__MSG__DETAIL__DETECTION_LIST__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "radar_msgs/msg/detail/detection_list__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"
// Member 'list_detections'
#include "radar_msgs/msg/detail/detection__traits.hpp"

namespace radar_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const DetectionList & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: crc
  {
    out << "crc: ";
    rosidl_generator_traits::value_to_yaml(msg.crc, out);
    out << ", ";
  }

  // member: length
  {
    out << "length: ";
    rosidl_generator_traits::value_to_yaml(msg.length, out);
    out << ", ";
  }

  // member: sqc
  {
    out << "sqc: ";
    rosidl_generator_traits::value_to_yaml(msg.sqc, out);
    out << ", ";
  }

  // member: data_id
  {
    out << "data_id: ";
    rosidl_generator_traits::value_to_yaml(msg.data_id, out);
    out << ", ";
  }

  // member: version_code
  {
    out << "version_code: ";
    rosidl_generator_traits::value_to_yaml(msg.version_code, out);
    out << ", ";
  }

  // member: frame_count
  {
    out << "frame_count: ";
    rosidl_generator_traits::value_to_yaml(msg.frame_count, out);
    out << ", ";
  }

  // member: frame_period_time
  {
    out << "frame_period_time: ";
    rosidl_generator_traits::value_to_yaml(msg.frame_period_time, out);
    out << ", ";
  }

  // member: timestamp_nanoseconds
  {
    out << "timestamp_nanoseconds: ";
    rosidl_generator_traits::value_to_yaml(msg.timestamp_nanoseconds, out);
    out << ", ";
  }

  // member: timestamp_seconds
  {
    out << "timestamp_seconds: ";
    rosidl_generator_traits::value_to_yaml(msg.timestamp_seconds, out);
    out << ", ";
  }

  // member: timestamp_sync_status
  {
    out << "timestamp_sync_status: ";
    rosidl_generator_traits::value_to_yaml(msg.timestamp_sync_status, out);
    out << ", ";
  }

  // member: rsv1
  {
    out << "rsv1: ";
    rosidl_generator_traits::value_to_yaml(msg.rsv1, out);
    out << ", ";
  }

  // member: rsv2
  {
    out << "rsv2: ";
    rosidl_generator_traits::value_to_yaml(msg.rsv2, out);
    out << ", ";
  }

  // member: coordinate_system
  {
    out << "coordinate_system: ";
    rosidl_generator_traits::value_to_yaml(msg.coordinate_system, out);
    out << ", ";
  }

  // member: measurement_latency
  {
    out << "measurement_latency: ";
    rosidl_generator_traits::value_to_yaml(msg.measurement_latency, out);
    out << ", ";
  }

  // member: origin_invalid_flags
  {
    out << "origin_invalid_flags: ";
    rosidl_generator_traits::value_to_yaml(msg.origin_invalid_flags, out);
    out << ", ";
  }

  // member: origin_xpos
  {
    out << "origin_xpos: ";
    rosidl_generator_traits::value_to_yaml(msg.origin_xpos, out);
    out << ", ";
  }

  // member: origin_xstd
  {
    out << "origin_xstd: ";
    rosidl_generator_traits::value_to_yaml(msg.origin_xstd, out);
    out << ", ";
  }

  // member: origin_ypos
  {
    out << "origin_ypos: ";
    rosidl_generator_traits::value_to_yaml(msg.origin_ypos, out);
    out << ", ";
  }

  // member: origin_ystd
  {
    out << "origin_ystd: ";
    rosidl_generator_traits::value_to_yaml(msg.origin_ystd, out);
    out << ", ";
  }

  // member: origin_zpos
  {
    out << "origin_zpos: ";
    rosidl_generator_traits::value_to_yaml(msg.origin_zpos, out);
    out << ", ";
  }

  // member: origin_zstd
  {
    out << "origin_zstd: ";
    rosidl_generator_traits::value_to_yaml(msg.origin_zstd, out);
    out << ", ";
  }

  // member: origin_roll
  {
    out << "origin_roll: ";
    rosidl_generator_traits::value_to_yaml(msg.origin_roll, out);
    out << ", ";
  }

  // member: origin_rollstd
  {
    out << "origin_rollstd: ";
    rosidl_generator_traits::value_to_yaml(msg.origin_rollstd, out);
    out << ", ";
  }

  // member: origin_pitch
  {
    out << "origin_pitch: ";
    rosidl_generator_traits::value_to_yaml(msg.origin_pitch, out);
    out << ", ";
  }

  // member: origin_pitchstd
  {
    out << "origin_pitchstd: ";
    rosidl_generator_traits::value_to_yaml(msg.origin_pitchstd, out);
    out << ", ";
  }

  // member: origin_yaw
  {
    out << "origin_yaw: ";
    rosidl_generator_traits::value_to_yaml(msg.origin_yaw, out);
    out << ", ";
  }

  // member: origin_yawstd
  {
    out << "origin_yawstd: ";
    rosidl_generator_traits::value_to_yaml(msg.origin_yawstd, out);
    out << ", ";
  }

  // member: list_invalid_flags
  {
    out << "list_invalid_flags: ";
    rosidl_generator_traits::value_to_yaml(msg.list_invalid_flags, out);
    out << ", ";
  }

  // member: aln_azimuth_correction
  {
    out << "aln_azimuth_correction: ";
    rosidl_generator_traits::value_to_yaml(msg.aln_azimuth_correction, out);
    out << ", ";
  }

  // member: aln_elevation_correction
  {
    out << "aln_elevation_correction: ";
    rosidl_generator_traits::value_to_yaml(msg.aln_elevation_correction, out);
    out << ", ";
  }

  // member: rsv_weather
  {
    out << "rsv_weather: ";
    rosidl_generator_traits::value_to_yaml(msg.rsv_weather, out);
    out << ", ";
  }

  // member: rsv_road_status
  {
    out << "rsv_road_status: ";
    rosidl_generator_traits::value_to_yaml(msg.rsv_road_status, out);
    out << ", ";
  }

  // member: rsv_aucc_frame_count
  {
    out << "rsv_aucc_frame_count: ";
    rosidl_generator_traits::value_to_yaml(msg.rsv_aucc_frame_count, out);
    out << ", ";
  }

  // member: rsv_profile_id
  {
    out << "rsv_profile_id: ";
    rosidl_generator_traits::value_to_yaml(msg.rsv_profile_id, out);
    out << ", ";
  }

  // member: rsv_adc_anti_num
  {
    out << "rsv_adc_anti_num: ";
    rosidl_generator_traits::value_to_yaml(msg.rsv_adc_anti_num, out);
    out << ", ";
  }

  // member: rsv_adc_real_higer_thod_cnt
  {
    out << "rsv_adc_real_higer_thod_cnt: ";
    rosidl_generator_traits::value_to_yaml(msg.rsv_adc_real_higer_thod_cnt, out);
    out << ", ";
  }

  // member: rsv_adc_imag_higer_thod_cnt
  {
    out << "rsv_adc_imag_higer_thod_cnt: ";
    rosidl_generator_traits::value_to_yaml(msg.rsv_adc_imag_higer_thod_cnt, out);
    out << ", ";
  }

  // member: u_rsv_bfm_coeff_error_flag
  {
    out << "u_rsv_bfm_coeff_error_flag: ";
    rosidl_generator_traits::value_to_yaml(msg.u_rsv_bfm_coeff_error_flag, out);
    out << ", ";
  }

  // member: rsv_ci_noise_median
  {
    out << "rsv_ci_noise_median: ";
    rosidl_generator_traits::value_to_yaml(msg.rsv_ci_noise_median, out);
    out << ", ";
  }

  // member: rsv_nci_noise_median
  {
    out << "rsv_nci_noise_median: ";
    rosidl_generator_traits::value_to_yaml(msg.rsv_nci_noise_median, out);
    out << ", ";
  }

  // member: rsv3
  {
    if (msg.rsv3.size() == 0) {
      out << "rsv3: []";
    } else {
      out << "rsv3: [";
      size_t pending_items = msg.rsv3.size();
      for (auto item : msg.rsv3) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: list_len_of_detections
  {
    out << "list_len_of_detections: ";
    rosidl_generator_traits::value_to_yaml(msg.list_len_of_detections, out);
    out << ", ";
  }

  // member: list_num_of_detections
  {
    out << "list_num_of_detections: ";
    rosidl_generator_traits::value_to_yaml(msg.list_num_of_detections, out);
    out << ", ";
  }

  // member: list_detections
  {
    if (msg.list_detections.size() == 0) {
      out << "list_detections: []";
    } else {
      out << "list_detections: [";
      size_t pending_items = msg.list_detections.size();
      for (auto item : msg.list_detections) {
        to_flow_style_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const DetectionList & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: crc
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "crc: ";
    rosidl_generator_traits::value_to_yaml(msg.crc, out);
    out << "\n";
  }

  // member: length
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "length: ";
    rosidl_generator_traits::value_to_yaml(msg.length, out);
    out << "\n";
  }

  // member: sqc
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "sqc: ";
    rosidl_generator_traits::value_to_yaml(msg.sqc, out);
    out << "\n";
  }

  // member: data_id
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "data_id: ";
    rosidl_generator_traits::value_to_yaml(msg.data_id, out);
    out << "\n";
  }

  // member: version_code
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "version_code: ";
    rosidl_generator_traits::value_to_yaml(msg.version_code, out);
    out << "\n";
  }

  // member: frame_count
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "frame_count: ";
    rosidl_generator_traits::value_to_yaml(msg.frame_count, out);
    out << "\n";
  }

  // member: frame_period_time
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "frame_period_time: ";
    rosidl_generator_traits::value_to_yaml(msg.frame_period_time, out);
    out << "\n";
  }

  // member: timestamp_nanoseconds
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "timestamp_nanoseconds: ";
    rosidl_generator_traits::value_to_yaml(msg.timestamp_nanoseconds, out);
    out << "\n";
  }

  // member: timestamp_seconds
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "timestamp_seconds: ";
    rosidl_generator_traits::value_to_yaml(msg.timestamp_seconds, out);
    out << "\n";
  }

  // member: timestamp_sync_status
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "timestamp_sync_status: ";
    rosidl_generator_traits::value_to_yaml(msg.timestamp_sync_status, out);
    out << "\n";
  }

  // member: rsv1
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "rsv1: ";
    rosidl_generator_traits::value_to_yaml(msg.rsv1, out);
    out << "\n";
  }

  // member: rsv2
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "rsv2: ";
    rosidl_generator_traits::value_to_yaml(msg.rsv2, out);
    out << "\n";
  }

  // member: coordinate_system
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "coordinate_system: ";
    rosidl_generator_traits::value_to_yaml(msg.coordinate_system, out);
    out << "\n";
  }

  // member: measurement_latency
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "measurement_latency: ";
    rosidl_generator_traits::value_to_yaml(msg.measurement_latency, out);
    out << "\n";
  }

  // member: origin_invalid_flags
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "origin_invalid_flags: ";
    rosidl_generator_traits::value_to_yaml(msg.origin_invalid_flags, out);
    out << "\n";
  }

  // member: origin_xpos
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "origin_xpos: ";
    rosidl_generator_traits::value_to_yaml(msg.origin_xpos, out);
    out << "\n";
  }

  // member: origin_xstd
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "origin_xstd: ";
    rosidl_generator_traits::value_to_yaml(msg.origin_xstd, out);
    out << "\n";
  }

  // member: origin_ypos
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "origin_ypos: ";
    rosidl_generator_traits::value_to_yaml(msg.origin_ypos, out);
    out << "\n";
  }

  // member: origin_ystd
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "origin_ystd: ";
    rosidl_generator_traits::value_to_yaml(msg.origin_ystd, out);
    out << "\n";
  }

  // member: origin_zpos
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "origin_zpos: ";
    rosidl_generator_traits::value_to_yaml(msg.origin_zpos, out);
    out << "\n";
  }

  // member: origin_zstd
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "origin_zstd: ";
    rosidl_generator_traits::value_to_yaml(msg.origin_zstd, out);
    out << "\n";
  }

  // member: origin_roll
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "origin_roll: ";
    rosidl_generator_traits::value_to_yaml(msg.origin_roll, out);
    out << "\n";
  }

  // member: origin_rollstd
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "origin_rollstd: ";
    rosidl_generator_traits::value_to_yaml(msg.origin_rollstd, out);
    out << "\n";
  }

  // member: origin_pitch
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "origin_pitch: ";
    rosidl_generator_traits::value_to_yaml(msg.origin_pitch, out);
    out << "\n";
  }

  // member: origin_pitchstd
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "origin_pitchstd: ";
    rosidl_generator_traits::value_to_yaml(msg.origin_pitchstd, out);
    out << "\n";
  }

  // member: origin_yaw
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "origin_yaw: ";
    rosidl_generator_traits::value_to_yaml(msg.origin_yaw, out);
    out << "\n";
  }

  // member: origin_yawstd
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "origin_yawstd: ";
    rosidl_generator_traits::value_to_yaml(msg.origin_yawstd, out);
    out << "\n";
  }

  // member: list_invalid_flags
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "list_invalid_flags: ";
    rosidl_generator_traits::value_to_yaml(msg.list_invalid_flags, out);
    out << "\n";
  }

  // member: aln_azimuth_correction
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "aln_azimuth_correction: ";
    rosidl_generator_traits::value_to_yaml(msg.aln_azimuth_correction, out);
    out << "\n";
  }

  // member: aln_elevation_correction
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "aln_elevation_correction: ";
    rosidl_generator_traits::value_to_yaml(msg.aln_elevation_correction, out);
    out << "\n";
  }

  // member: rsv_weather
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "rsv_weather: ";
    rosidl_generator_traits::value_to_yaml(msg.rsv_weather, out);
    out << "\n";
  }

  // member: rsv_road_status
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "rsv_road_status: ";
    rosidl_generator_traits::value_to_yaml(msg.rsv_road_status, out);
    out << "\n";
  }

  // member: rsv_aucc_frame_count
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "rsv_aucc_frame_count: ";
    rosidl_generator_traits::value_to_yaml(msg.rsv_aucc_frame_count, out);
    out << "\n";
  }

  // member: rsv_profile_id
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "rsv_profile_id: ";
    rosidl_generator_traits::value_to_yaml(msg.rsv_profile_id, out);
    out << "\n";
  }

  // member: rsv_adc_anti_num
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "rsv_adc_anti_num: ";
    rosidl_generator_traits::value_to_yaml(msg.rsv_adc_anti_num, out);
    out << "\n";
  }

  // member: rsv_adc_real_higer_thod_cnt
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "rsv_adc_real_higer_thod_cnt: ";
    rosidl_generator_traits::value_to_yaml(msg.rsv_adc_real_higer_thod_cnt, out);
    out << "\n";
  }

  // member: rsv_adc_imag_higer_thod_cnt
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "rsv_adc_imag_higer_thod_cnt: ";
    rosidl_generator_traits::value_to_yaml(msg.rsv_adc_imag_higer_thod_cnt, out);
    out << "\n";
  }

  // member: u_rsv_bfm_coeff_error_flag
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "u_rsv_bfm_coeff_error_flag: ";
    rosidl_generator_traits::value_to_yaml(msg.u_rsv_bfm_coeff_error_flag, out);
    out << "\n";
  }

  // member: rsv_ci_noise_median
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "rsv_ci_noise_median: ";
    rosidl_generator_traits::value_to_yaml(msg.rsv_ci_noise_median, out);
    out << "\n";
  }

  // member: rsv_nci_noise_median
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "rsv_nci_noise_median: ";
    rosidl_generator_traits::value_to_yaml(msg.rsv_nci_noise_median, out);
    out << "\n";
  }

  // member: rsv3
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.rsv3.size() == 0) {
      out << "rsv3: []\n";
    } else {
      out << "rsv3:\n";
      for (auto item : msg.rsv3) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: list_len_of_detections
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "list_len_of_detections: ";
    rosidl_generator_traits::value_to_yaml(msg.list_len_of_detections, out);
    out << "\n";
  }

  // member: list_num_of_detections
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "list_num_of_detections: ";
    rosidl_generator_traits::value_to_yaml(msg.list_num_of_detections, out);
    out << "\n";
  }

  // member: list_detections
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.list_detections.size() == 0) {
      out << "list_detections: []\n";
    } else {
      out << "list_detections:\n";
      for (auto item : msg.list_detections) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_block_style_yaml(item, out, indentation + 2);
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const DetectionList & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace radar_msgs

namespace rosidl_generator_traits
{

[[deprecated("use radar_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const radar_msgs::msg::DetectionList & msg,
  std::ostream & out, size_t indentation = 0)
{
  radar_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use radar_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const radar_msgs::msg::DetectionList & msg)
{
  return radar_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<radar_msgs::msg::DetectionList>()
{
  return "radar_msgs::msg::DetectionList";
}

template<>
inline const char * name<radar_msgs::msg::DetectionList>()
{
  return "radar_msgs/msg/DetectionList";
}

template<>
struct has_fixed_size<radar_msgs::msg::DetectionList>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<radar_msgs::msg::DetectionList>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<radar_msgs::msg::DetectionList>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // RADAR_MSGS__MSG__DETAIL__DETECTION_LIST__TRAITS_HPP_
