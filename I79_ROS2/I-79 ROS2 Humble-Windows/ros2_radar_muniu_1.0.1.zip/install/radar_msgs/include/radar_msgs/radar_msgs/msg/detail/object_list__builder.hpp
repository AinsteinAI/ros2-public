// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from radar_msgs:msg\ObjectList.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__OBJECT_LIST__BUILDER_HPP_
#define RADAR_MSGS__MSG__DETAIL__OBJECT_LIST__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "radar_msgs/msg/detail/object_list__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace radar_msgs
{

namespace msg
{

namespace builder
{

class Init_ObjectList_objectlist_objects
{
public:
  explicit Init_ObjectList_objectlist_objects(::radar_msgs::msg::ObjectList & msg)
  : msg_(msg)
  {}
  ::radar_msgs::msg::ObjectList objectlist_objects(::radar_msgs::msg::ObjectList::_objectlist_objects_type arg)
  {
    msg_.objectlist_objects = std::move(arg);
    return std::move(msg_);
  }

private:
  ::radar_msgs::msg::ObjectList msg_;
};

class Init_ObjectList_objectlist_numofobjects
{
public:
  explicit Init_ObjectList_objectlist_numofobjects(::radar_msgs::msg::ObjectList & msg)
  : msg_(msg)
  {}
  Init_ObjectList_objectlist_objects objectlist_numofobjects(::radar_msgs::msg::ObjectList::_objectlist_numofobjects_type arg)
  {
    msg_.objectlist_numofobjects = std::move(arg);
    return Init_ObjectList_objectlist_objects(msg_);
  }

private:
  ::radar_msgs::msg::ObjectList msg_;
};

class Init_ObjectList_rsv3
{
public:
  explicit Init_ObjectList_rsv3(::radar_msgs::msg::ObjectList & msg)
  : msg_(msg)
  {}
  Init_ObjectList_objectlist_numofobjects rsv3(::radar_msgs::msg::ObjectList::_rsv3_type arg)
  {
    msg_.rsv3 = std::move(arg);
    return Init_ObjectList_objectlist_numofobjects(msg_);
  }

private:
  ::radar_msgs::msg::ObjectList msg_;
};

class Init_ObjectList_measurement_latency
{
public:
  explicit Init_ObjectList_measurement_latency(::radar_msgs::msg::ObjectList & msg)
  : msg_(msg)
  {}
  Init_ObjectList_rsv3 measurement_latency(::radar_msgs::msg::ObjectList::_measurement_latency_type arg)
  {
    msg_.measurement_latency = std::move(arg);
    return Init_ObjectList_rsv3(msg_);
  }

private:
  ::radar_msgs::msg::ObjectList msg_;
};

class Init_ObjectList_coordinate_system
{
public:
  explicit Init_ObjectList_coordinate_system(::radar_msgs::msg::ObjectList & msg)
  : msg_(msg)
  {}
  Init_ObjectList_measurement_latency coordinate_system(::radar_msgs::msg::ObjectList::_coordinate_system_type arg)
  {
    msg_.coordinate_system = std::move(arg);
    return Init_ObjectList_measurement_latency(msg_);
  }

private:
  ::radar_msgs::msg::ObjectList msg_;
};

class Init_ObjectList_frame_count
{
public:
  explicit Init_ObjectList_frame_count(::radar_msgs::msg::ObjectList & msg)
  : msg_(msg)
  {}
  Init_ObjectList_coordinate_system frame_count(::radar_msgs::msg::ObjectList::_frame_count_type arg)
  {
    msg_.frame_count = std::move(arg);
    return Init_ObjectList_coordinate_system(msg_);
  }

private:
  ::radar_msgs::msg::ObjectList msg_;
};

class Init_ObjectList_rsv2
{
public:
  explicit Init_ObjectList_rsv2(::radar_msgs::msg::ObjectList & msg)
  : msg_(msg)
  {}
  Init_ObjectList_frame_count rsv2(::radar_msgs::msg::ObjectList::_rsv2_type arg)
  {
    msg_.rsv2 = std::move(arg);
    return Init_ObjectList_frame_count(msg_);
  }

private:
  ::radar_msgs::msg::ObjectList msg_;
};

class Init_ObjectList_rsv1
{
public:
  explicit Init_ObjectList_rsv1(::radar_msgs::msg::ObjectList & msg)
  : msg_(msg)
  {}
  Init_ObjectList_rsv2 rsv1(::radar_msgs::msg::ObjectList::_rsv1_type arg)
  {
    msg_.rsv1 = std::move(arg);
    return Init_ObjectList_rsv2(msg_);
  }

private:
  ::radar_msgs::msg::ObjectList msg_;
};

class Init_ObjectList_timestamp_syncstatus
{
public:
  explicit Init_ObjectList_timestamp_syncstatus(::radar_msgs::msg::ObjectList & msg)
  : msg_(msg)
  {}
  Init_ObjectList_rsv1 timestamp_syncstatus(::radar_msgs::msg::ObjectList::_timestamp_syncstatus_type arg)
  {
    msg_.timestamp_syncstatus = std::move(arg);
    return Init_ObjectList_rsv1(msg_);
  }

private:
  ::radar_msgs::msg::ObjectList msg_;
};

class Init_ObjectList_timestamp_seconds
{
public:
  explicit Init_ObjectList_timestamp_seconds(::radar_msgs::msg::ObjectList & msg)
  : msg_(msg)
  {}
  Init_ObjectList_timestamp_syncstatus timestamp_seconds(::radar_msgs::msg::ObjectList::_timestamp_seconds_type arg)
  {
    msg_.timestamp_seconds = std::move(arg);
    return Init_ObjectList_timestamp_syncstatus(msg_);
  }

private:
  ::radar_msgs::msg::ObjectList msg_;
};

class Init_ObjectList_timestamp_nanoseconds
{
public:
  explicit Init_ObjectList_timestamp_nanoseconds(::radar_msgs::msg::ObjectList & msg)
  : msg_(msg)
  {}
  Init_ObjectList_timestamp_seconds timestamp_nanoseconds(::radar_msgs::msg::ObjectList::_timestamp_nanoseconds_type arg)
  {
    msg_.timestamp_nanoseconds = std::move(arg);
    return Init_ObjectList_timestamp_seconds(msg_);
  }

private:
  ::radar_msgs::msg::ObjectList msg_;
};

class Init_ObjectList_dataid
{
public:
  explicit Init_ObjectList_dataid(::radar_msgs::msg::ObjectList & msg)
  : msg_(msg)
  {}
  Init_ObjectList_timestamp_nanoseconds dataid(::radar_msgs::msg::ObjectList::_dataid_type arg)
  {
    msg_.dataid = std::move(arg);
    return Init_ObjectList_timestamp_nanoseconds(msg_);
  }

private:
  ::radar_msgs::msg::ObjectList msg_;
};

class Init_ObjectList_sqc
{
public:
  explicit Init_ObjectList_sqc(::radar_msgs::msg::ObjectList & msg)
  : msg_(msg)
  {}
  Init_ObjectList_dataid sqc(::radar_msgs::msg::ObjectList::_sqc_type arg)
  {
    msg_.sqc = std::move(arg);
    return Init_ObjectList_dataid(msg_);
  }

private:
  ::radar_msgs::msg::ObjectList msg_;
};

class Init_ObjectList_length
{
public:
  explicit Init_ObjectList_length(::radar_msgs::msg::ObjectList & msg)
  : msg_(msg)
  {}
  Init_ObjectList_sqc length(::radar_msgs::msg::ObjectList::_length_type arg)
  {
    msg_.length = std::move(arg);
    return Init_ObjectList_sqc(msg_);
  }

private:
  ::radar_msgs::msg::ObjectList msg_;
};

class Init_ObjectList_crc
{
public:
  explicit Init_ObjectList_crc(::radar_msgs::msg::ObjectList & msg)
  : msg_(msg)
  {}
  Init_ObjectList_length crc(::radar_msgs::msg::ObjectList::_crc_type arg)
  {
    msg_.crc = std::move(arg);
    return Init_ObjectList_length(msg_);
  }

private:
  ::radar_msgs::msg::ObjectList msg_;
};

class Init_ObjectList_header
{
public:
  Init_ObjectList_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ObjectList_crc header(::radar_msgs::msg::ObjectList::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_ObjectList_crc(msg_);
  }

private:
  ::radar_msgs::msg::ObjectList msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::radar_msgs::msg::ObjectList>()
{
  return radar_msgs::msg::builder::Init_ObjectList_header();
}

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__OBJECT_LIST__BUILDER_HPP_
