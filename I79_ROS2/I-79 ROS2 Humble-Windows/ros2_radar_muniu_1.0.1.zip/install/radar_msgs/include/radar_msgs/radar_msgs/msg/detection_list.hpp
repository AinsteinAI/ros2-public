// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETECTION_LIST_HPP_
#define RADAR_MSGS__MSG__DETECTION_LIST_HPP_

#include "radar_msgs/msg/detail/detection_list__struct.hpp"
#include "radar_msgs/msg/detail/detection_list__builder.hpp"
#include "radar_msgs/msg/detail/detection_list__traits.hpp"

#endif  // RADAR_MSGS__MSG__DETECTION_LIST_HPP_
