// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from radar_msgs:msg\Detection.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__DETECTION__BUILDER_HPP_
#define RADAR_MSGS__MSG__DETAIL__DETECTION__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "radar_msgs/msg/detail/detection__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace radar_msgs
{

namespace msg
{

namespace builder
{

class Init_Detection_ambiguity_flag
{
public:
  explicit Init_Detection_ambiguity_flag(::radar_msgs::msg::Detection & msg)
  : msg_(msg)
  {}
  ::radar_msgs::msg::Detection ambiguity_flag(::radar_msgs::msg::Detection::_ambiguity_flag_type arg)
  {
    msg_.ambiguity_flag = std::move(arg);
    return std::move(msg_);
  }

private:
  ::radar_msgs::msg::Detection msg_;
};

class Init_Detection_classification
{
public:
  explicit Init_Detection_classification(::radar_msgs::msg::Detection & msg)
  : msg_(msg)
  {}
  Init_Detection_ambiguity_flag classification(::radar_msgs::msg::Detection::_classification_type arg)
  {
    msg_.classification = std::move(arg);
    return Init_Detection_ambiguity_flag(msg_);
  }

private:
  ::radar_msgs::msg::Detection msg_;
};

class Init_Detection_positive_predictive_value
{
public:
  explicit Init_Detection_positive_predictive_value(::radar_msgs::msg::Detection & msg)
  : msg_(msg)
  {}
  Init_Detection_classification positive_predictive_value(::radar_msgs::msg::Detection::_positive_predictive_value_type arg)
  {
    msg_.positive_predictive_value = std::move(arg);
    return Init_Detection_classification(msg_);
  }

private:
  ::radar_msgs::msg::Detection msg_;
};

class Init_Detection_snr
{
public:
  explicit Init_Detection_snr(::radar_msgs::msg::Detection & msg)
  : msg_(msg)
  {}
  Init_Detection_positive_predictive_value snr(::radar_msgs::msg::Detection::_snr_type arg)
  {
    msg_.snr = std::move(arg);
    return Init_Detection_positive_predictive_value(msg_);
  }

private:
  ::radar_msgs::msg::Detection msg_;
};

class Init_Detection_rcs
{
public:
  explicit Init_Detection_rcs(::radar_msgs::msg::Detection & msg)
  : msg_(msg)
  {}
  Init_Detection_snr rcs(::radar_msgs::msg::Detection::_rcs_type arg)
  {
    msg_.rcs = std::move(arg);
    return Init_Detection_snr(msg_);
  }

private:
  ::radar_msgs::msg::Detection msg_;
};

class Init_Detection_range_rate_std
{
public:
  explicit Init_Detection_range_rate_std(::radar_msgs::msg::Detection & msg)
  : msg_(msg)
  {}
  Init_Detection_rcs range_rate_std(::radar_msgs::msg::Detection::_range_rate_std_type arg)
  {
    msg_.range_rate_std = std::move(arg);
    return Init_Detection_rcs(msg_);
  }

private:
  ::radar_msgs::msg::Detection msg_;
};

class Init_Detection_range_rate
{
public:
  explicit Init_Detection_range_rate(::radar_msgs::msg::Detection & msg)
  : msg_(msg)
  {}
  Init_Detection_range_rate_std range_rate(::radar_msgs::msg::Detection::_range_rate_type arg)
  {
    msg_.range_rate = std::move(arg);
    return Init_Detection_range_rate_std(msg_);
  }

private:
  ::radar_msgs::msg::Detection msg_;
};

class Init_Detection_range_std
{
public:
  explicit Init_Detection_range_std(::radar_msgs::msg::Detection & msg)
  : msg_(msg)
  {}
  Init_Detection_range_rate range_std(::radar_msgs::msg::Detection::_range_std_type arg)
  {
    msg_.range_std = std::move(arg);
    return Init_Detection_range_rate(msg_);
  }

private:
  ::radar_msgs::msg::Detection msg_;
};

class Init_Detection_range
{
public:
  explicit Init_Detection_range(::radar_msgs::msg::Detection & msg)
  : msg_(msg)
  {}
  Init_Detection_range_std range(::radar_msgs::msg::Detection::_range_type arg)
  {
    msg_.range = std::move(arg);
    return Init_Detection_range_std(msg_);
  }

private:
  ::radar_msgs::msg::Detection msg_;
};

class Init_Detection_elevation_angle_std
{
public:
  explicit Init_Detection_elevation_angle_std(::radar_msgs::msg::Detection & msg)
  : msg_(msg)
  {}
  Init_Detection_range elevation_angle_std(::radar_msgs::msg::Detection::_elevation_angle_std_type arg)
  {
    msg_.elevation_angle_std = std::move(arg);
    return Init_Detection_range(msg_);
  }

private:
  ::radar_msgs::msg::Detection msg_;
};

class Init_Detection_elevation_angle
{
public:
  explicit Init_Detection_elevation_angle(::radar_msgs::msg::Detection & msg)
  : msg_(msg)
  {}
  Init_Detection_elevation_angle_std elevation_angle(::radar_msgs::msg::Detection::_elevation_angle_type arg)
  {
    msg_.elevation_angle = std::move(arg);
    return Init_Detection_elevation_angle_std(msg_);
  }

private:
  ::radar_msgs::msg::Detection msg_;
};

class Init_Detection_invalid_flags
{
public:
  explicit Init_Detection_invalid_flags(::radar_msgs::msg::Detection & msg)
  : msg_(msg)
  {}
  Init_Detection_elevation_angle invalid_flags(::radar_msgs::msg::Detection::_invalid_flags_type arg)
  {
    msg_.invalid_flags = std::move(arg);
    return Init_Detection_elevation_angle(msg_);
  }

private:
  ::radar_msgs::msg::Detection msg_;
};

class Init_Detection_azimuth_angle_std
{
public:
  explicit Init_Detection_azimuth_angle_std(::radar_msgs::msg::Detection & msg)
  : msg_(msg)
  {}
  Init_Detection_invalid_flags azimuth_angle_std(::radar_msgs::msg::Detection::_azimuth_angle_std_type arg)
  {
    msg_.azimuth_angle_std = std::move(arg);
    return Init_Detection_invalid_flags(msg_);
  }

private:
  ::radar_msgs::msg::Detection msg_;
};

class Init_Detection_azimuth_angle
{
public:
  explicit Init_Detection_azimuth_angle(::radar_msgs::msg::Detection & msg)
  : msg_(msg)
  {}
  Init_Detection_azimuth_angle_std azimuth_angle(::radar_msgs::msg::Detection::_azimuth_angle_type arg)
  {
    msg_.azimuth_angle = std::move(arg);
    return Init_Detection_azimuth_angle_std(msg_);
  }

private:
  ::radar_msgs::msg::Detection msg_;
};

class Init_Detection_measurement_id
{
public:
  Init_Detection_measurement_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Detection_azimuth_angle measurement_id(::radar_msgs::msg::Detection::_measurement_id_type arg)
  {
    msg_.measurement_id = std::move(arg);
    return Init_Detection_azimuth_angle(msg_);
  }

private:
  ::radar_msgs::msg::Detection msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::radar_msgs::msg::Detection>()
{
  return radar_msgs::msg::builder::Init_Detection_measurement_id();
}

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__DETECTION__BUILDER_HPP_
